Tests removed per request.

// src/shared/constants.js
var MESSAGE = Object.freeze({
  UI_START: "ui.start",
  UI_CANCEL: "ui.cancel",
  UI_CLEAR: "ui.clear",
  UI_SWITCH_VIEW: "ui.switch_view",
  UI_STATE: "ui.state",
  UI_PING: "ui.ping",
  UI_LOAD_SETTINGS: "ui.load_settings",
  UI_SAVE_SETTINGS: "ui.save_settings",
  UI_SAVE_PROFILE: "ui.save_profile",
  UI_LIST_MODELS: "ui.list_models",
  UI_LIST_PROFILES: "ui.list_profiles",
  LOG_QUERY: "log.query",
  LOG_EXPORT: "log.export",
  LOG_CLEAR: "log.clear",
  CONTENT_SCAN: "content.scan",
  CONTENT_APPLY_BATCH: "content.apply_batch",
  CONTENT_SWITCH_VIEW: "content.switch_view",
  CONTENT_CLEAR: "content.clear",
  OFFSCREEN_EXECUTE: "offscreen.execute",
  OFFSCREEN_CANCEL: "offscreen.cancel",
  PIPELINE_RESUME: "pipeline.resume"
});
var VIEW_MODE = Object.freeze({
  TRANSLATION: "translation",
  ORIGINAL: "original",
  DIFF: "diff"
});
var PIPELINE_STAGE = Object.freeze({
  IDLE: "idle",
  SCANNING: "scanning",
  CONTEXT: "context",
  BATCHING: "batching",
  TRANSLATING: "translating",
  APPLYING: "applying",
  DONE: "done",
  CANCELLED: "cancelled",
  FAILED: "failed"
});
var LOG_LEVEL = Object.freeze({
  DEBUG: "debug",
  INFO: "info",
  WARN: "warn",
  ERROR: "error"
});
var EVENT_CATEGORY = Object.freeze({
  UI_ACTION: "ui.action",
  PIPELINE_STAGE: "pipeline.stage",
  DOM_SCAN: "dom.scan",
  DOM_CLASSIFY: "dom.classify",
  DOM_APPLY: "dom.apply",
  CONTEXT_GENERATE: "context.generate",
  CONTEXT_COMPACT: "context.compact",
  BATCH_CREATE: "batch.create",
  BATCH_TRANSLATE: "batch.translate",
  OPENAI_REQUEST: "openai.request",
  OPENAI_RESPONSE: "openai.response",
  OPENAI_RATE_LIMIT: "openai.rate_limit",
  CANCELLATION: "cancellation",
  STORAGE_GC: "storage.gc",
  ERROR: "error"
});
var STORAGE_KEYS = Object.freeze({
  SETTINGS: "settings",
  PROFILES: "profiles",
  TAB_STATES: "tabStates",
  ACTIVE_SESSION_BY_TAB: "activeSessionByTab"
});
var DEFAULT_SETTINGS = Object.freeze({
  activeProfileName: "default",
  selectedViewMode: VIEW_MODE.ORIGINAL,
  accessMode: "BYOK",
  byokApiKey: "",
  byokBaseUrl: "https://api.openai.com/v1",
  proxyToken: "",
  proxyBaseUrl: "",
  promptCaching: {
    enabled: true,
    scope: "profile"
  },
  globalContext: {
    targetTokens: 15e3,
    maxOutputTokens: 4096,
    model: "gpt-4.1-mini"
  },
  batching: {
    blockLimits: {
      minChars: 1,
      maxChars: 2800
    },
    batchTokenTarget: 1200,
    maxBlocksPerBatch: 24
  },
  batchWindow: {
    prevBatchesCount: 3,
    compactAfter: 8,
    compactPolicy: "rolling"
  },
  compaction: {
    model: "gpt-4.1-mini",
    prompt: "Compact translated history preserving terms and entities.",
    thresholds: {
      tokenTarget: 450,
      startAfterBatch: 8
    }
  },
  storagePolicy: {
    whatToKeep: "full",
    maxBytes: 3e6,
    maxRecords: 8e3,
    maxAgeMs: 1e3 * 60 * 60 * 24 * 7,
    gcPolicy: "lru"
  },
  models: {
    selected: ["gpt-4.1-mini", "gpt-4.1-nano"],
    sortablePricing: true
  },
  modelPriority: {
    context: ["gpt-4.1-mini", "gpt-4.1-nano"],
    translation: ["gpt-4.1-mini", "gpt-4.1-nano"]
  },
  rateLimits: {
    safetyBufferTokens: 500,
    perModel: {
      "gpt-4.1-mini": { tpm: 18e4, rpm: 500, concurrency: 3 },
      "gpt-4.1-nano": { tpm: 3e5, rpm: 600, concurrency: 4 }
    }
  },
  mockMode: {
    enabled: false,
    artificialDelayMs: 120,
    forceError: false
  }
});
var DEFAULT_PROFILE_TEMPLATE = Object.freeze({
  promptCaching: { ...DEFAULT_SETTINGS.promptCaching },
  globalContext: { ...DEFAULT_SETTINGS.globalContext },
  batching: { ...DEFAULT_SETTINGS.batching },
  batchWindow: { ...DEFAULT_SETTINGS.batchWindow },
  compaction: { ...DEFAULT_SETTINGS.compaction },
  storagePolicy: { ...DEFAULT_SETTINGS.storagePolicy },
  models: { ...DEFAULT_SETTINGS.models },
  modelPriority: { ...DEFAULT_SETTINGS.modelPriority },
  rateLimits: { ...DEFAULT_SETTINGS.rateLimits }
});
var MODEL_PRICE_CATALOG = Object.freeze({
  "gpt-4.1": { input: 10, output: 30, cachedInput: 2.5 },
  "gpt-4.1-mini": { input: 0.8, output: 3.2, cachedInput: 0.2 },
  "gpt-4.1-nano": { input: 0.2, output: 0.8, cachedInput: 0.05 },
  "gpt-5": { input: 15, output: 45, cachedInput: 3.75 },
  "gpt-5-mini": { input: 1.2, output: 4.8, cachedInput: 0.3 },
  "gpt-5-nano": { input: 0.4, output: 1.6, cachedInput: 0.1 }
});
var OFFSCREEN_DOCUMENT_PATH = "offscreen/offscreen.html";
var ALARM_RESUME_PIPELINE = "pipeline_resume";
var EVENT_STREAM_PORT = "event_stream_port";

// src/shared/idb.js
function openDatabase({ dbName, version, upgrade }) {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(dbName, version);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event) => upgrade(request.result, event.oldVersion, event.newVersion);
  });
}
function transactionDone(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || new Error("Transaction aborted"));
  });
}
function requestToPromise(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

// src/shared/utils.js
function deepClone(value) {
  return structuredClone(value);
}
function nowIso() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function estimateTokens(text) {
  if (!text) {
    return 0;
  }
  return Math.max(1, Math.ceil(text.length / 4));
}
function stableHash(input) {
  const text = typeof input === "string" ? input : JSON.stringify(input);
  let hash = 2166136261;
  for (let i = 0; i < text.length; i += 1) {
    hash ^= text.charCodeAt(i);
    hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}
function buildPageSessionId({ tabId, url, nonce }) {
  const safeUrl = String(url || "unknown").slice(0, 1200);
  const ts = Date.now();
  return `ps_${tabId}_${stableHash(`${safeUrl}_${nonce || ts}_${ts}`)}`;
}
function buildBatchId(pageSessionId, index, blockIds) {
  return `b_${stableHash(`${pageSessionId}_${index}_${blockIds.join("|")}`)}`;
}
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function parseRetryAfterSeconds(headers) {
  if (!headers || typeof headers.get !== "function") {
    return null;
  }
  const raw = headers.get("retry-after");
  if (!raw) {
    return null;
  }
  const seconds = Number.parseInt(raw, 10);
  if (Number.isFinite(seconds)) {
    return Math.max(0, seconds);
  }
  const parsedDate = Date.parse(raw);
  if (Number.isFinite(parsedDate)) {
    const delayMs = parsedDate - Date.now();
    return Math.max(0, Math.ceil(delayMs / 1e3));
  }
  return null;
}
function asErrorObject(error) {
  if (!error) {
    return null;
  }
  if (typeof error === "string") {
    return { message: error };
  }
  return {
    name: error.name,
    message: error.message,
    stack: error.stack
  };
}

// src/shared/redact.js
var SECRET_KEYS = ["apikey", "api_key", "token", "authorization", "proxytoken"];
function redactSecrets(input) {
  return redactRecursively(input);
}
function redactRecursively(value) {
  if (Array.isArray(value)) {
    return value.map(redactRecursively);
  }
  if (value && typeof value === "object") {
    const next = {};
    for (const [key, nestedValue] of Object.entries(value)) {
      if (isSecretKey(key)) {
        next[key] = "***REDACTED***";
      } else {
        next[key] = redactRecursively(nestedValue);
      }
    }
    return next;
  }
  return value;
}
function isSecretKey(key) {
  const normalized = String(key).replace(/[^a-zA-Z]/g, "").toLowerCase();
  return SECRET_KEYS.some((secretKey) => normalized.includes(secretKey));
}

// src/shared/event-log-store.js
var DB_NAME = "neuro_translate_db";
var DB_VERSION = 1;
var STORE_NAME = "event_logs";
var EventLogStore = class {
  constructor({
    maxRecords = 8e3,
    maxAgeMs = 1e3 * 60 * 60 * 24 * 7,
    maxBytes = 3e6
  } = {}) {
    this.maxRecords = maxRecords;
    this.maxAgeMs = maxAgeMs;
    this.maxBytes = maxBytes;
    this.dbPromise = null;
  }
  async db() {
    if (!this.dbPromise) {
      this.dbPromise = openDatabase({
        dbName: DB_NAME,
        version: DB_VERSION,
        upgrade: (db) => {
          if (!db.objectStoreNames.contains(STORE_NAME)) {
            const store = db.createObjectStore(STORE_NAME, { keyPath: "id", autoIncrement: true });
            store.createIndex("by_ts", "ts");
            store.createIndex("by_category", "category");
            store.createIndex("by_level", "level");
            store.createIndex("by_pageSessionId", "pageSessionId");
          }
        }
      });
    }
    return this.dbPromise;
  }
  normalizeEvent(event) {
    const normalized = {
      ts: event.ts || nowIso(),
      level: event.level || LOG_LEVEL.INFO,
      category: event.category || EVENT_CATEGORY.UI_ACTION,
      name: event.name || "event",
      pageSessionId: event.pageSessionId || null,
      tabId: event.tabId ?? null,
      batchId: event.batchId || null,
      blockId: event.blockId || null,
      data: redactSecrets(event.data || {}),
      error: redactSecrets(event.error || null)
    };
    return normalized;
  }
  async append(event) {
    const db = await this.db();
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).add(this.normalizeEvent(event));
    await transactionDone(tx);
  }
  async appendMany(events) {
    if (!events.length) {
      return;
    }
    const db = await this.db();
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    for (const event of events) {
      store.add(this.normalizeEvent(event));
    }
    await transactionDone(tx);
  }
  async query({
    level,
    category,
    pageSessionId,
    onlyErrors = false,
    limit = 500,
    offset = 0,
    sort = "desc"
  } = {}) {
    const db = await this.db();
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);
    const rows = await requestToPromise(store.getAll());
    await transactionDone(tx);
    const filtered = rows.filter((row) => {
      if (level && row.level !== level) {
        return false;
      }
      if (category && row.category !== category) {
        return false;
      }
      if (pageSessionId && row.pageSessionId !== pageSessionId) {
        return false;
      }
      if (onlyErrors && row.level !== LOG_LEVEL.ERROR) {
        return false;
      }
      return true;
    });
    filtered.sort((a, b) => sort === "asc" ? String(a.ts).localeCompare(String(b.ts)) : String(b.ts).localeCompare(String(a.ts)));
    return {
      total: filtered.length,
      items: filtered.slice(offset, offset + limit)
    };
  }
  async clear() {
    const db = await this.db();
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).clear();
    await transactionDone(tx);
  }
  async exportJson(filters = {}) {
    const data = await this.query({ ...filters, limit: Number.MAX_SAFE_INTEGER, offset: 0, sort: "asc" });
    return JSON.stringify(data.items, null, 2);
  }
  async gc() {
    const db = await this.db();
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);
    const allRows = await requestToPromise(store.getAll());
    await transactionDone(tx);
    const now = Date.now();
    const expiredThreshold = now - this.maxAgeMs;
    const toDeleteByAge = allRows.filter((row) => Date.parse(row.ts) < expiredThreshold).map((row) => row.id);
    let overLimitDeleteIds = [];
    if (allRows.length - toDeleteByAge.length > this.maxRecords) {
      const sortedAsc = allRows.filter((row) => !toDeleteByAge.includes(row.id)).sort((a, b) => String(a.ts).localeCompare(String(b.ts)));
      const over = sortedAsc.length - this.maxRecords;
      overLimitDeleteIds = sortedAsc.slice(0, over).map((row) => row.id);
    }
    const keepRowsByAgeAndCount = allRows.filter((row) => !toDeleteByAge.includes(row.id) && !overLimitDeleteIds.includes(row.id)).sort((a, b) => String(a.ts).localeCompare(String(b.ts)));
    let estimatedBytes = keepRowsByAgeAndCount.reduce((sum, row) => sum + estimateEventBytes(row), 0);
    const overBytesDeleteIds = [];
    if (estimatedBytes > this.maxBytes) {
      for (const row of keepRowsByAgeAndCount) {
        if (estimatedBytes <= this.maxBytes) {
          break;
        }
        overBytesDeleteIds.push(row.id);
        estimatedBytes -= estimateEventBytes(row);
      }
    }
    const deleteIds = [...toDeleteByAge, ...overLimitDeleteIds, ...overBytesDeleteIds];
    if (!deleteIds.length) {
      return { removed: 0 };
    }
    const writeTx = db.transaction(STORE_NAME, "readwrite");
    const writeStore = writeTx.objectStore(STORE_NAME);
    for (const id of deleteIds) {
      writeStore.delete(id);
    }
    await transactionDone(writeTx);
    return {
      removed: deleteIds.length,
      removedByAge: toDeleteByAge.length,
      removedByMaxRecords: overLimitDeleteIds.length,
      removedByMaxBytes: overBytesDeleteIds.length
    };
  }
};
function estimateEventBytes(row) {
  try {
    return JSON.stringify(row).length * 2;
  } catch {
    return 1024;
  }
}

// src/shared/settings-store.js
var SettingsStore = class {
  async init() {
    const raw = await chrome.storage.local.get([
      STORAGE_KEYS.SETTINGS,
      STORAGE_KEYS.PROFILES
    ]);
    if (!raw?.[STORAGE_KEYS.SETTINGS]) {
      const defaults = this.withDefaultProfile(deepClone(DEFAULT_SETTINGS));
      await chrome.storage.local.set({ [STORAGE_KEYS.SETTINGS]: defaults });
    }
    if (!raw?.[STORAGE_KEYS.PROFILES]) {
      await chrome.storage.local.set({
        [STORAGE_KEYS.PROFILES]: {
          default: deepClone(DEFAULT_PROFILE_TEMPLATE)
        }
      });
    }
  }
  withDefaultProfile(settings) {
    return {
      ...settings,
      profileDraft: deepClone(DEFAULT_PROFILE_TEMPLATE)
    };
  }
  async getSettings() {
    await this.init();
    const raw = await chrome.storage.local.get([STORAGE_KEYS.SETTINGS]);
    const settings = raw?.[STORAGE_KEYS.SETTINGS] || deepClone(DEFAULT_SETTINGS);
    if (!settings.profileDraft) {
      settings.profileDraft = deepClone(DEFAULT_PROFILE_TEMPLATE);
    }
    return settings;
  }
  async saveSettings(nextSettings) {
    await chrome.storage.local.set({ [STORAGE_KEYS.SETTINGS]: nextSettings });
    return nextSettings;
  }
  async listProfiles() {
    await this.init();
    const raw = await chrome.storage.local.get([STORAGE_KEYS.PROFILES]);
    return raw?.[STORAGE_KEYS.PROFILES] || { default: deepClone(DEFAULT_PROFILE_TEMPLATE) };
  }
  async saveProfile(name, profile) {
    const profiles = await this.listProfiles();
    profiles[name] = profile;
    await chrome.storage.local.set({ [STORAGE_KEYS.PROFILES]: profiles });
    return profiles;
  }
  async deleteProfile(name) {
    if (name === "default") {
      return this.listProfiles();
    }
    const profiles = await this.listProfiles();
    delete profiles[name];
    await chrome.storage.local.set({ [STORAGE_KEYS.PROFILES]: profiles });
    return profiles;
  }
};

// src/shared/tab-state-store.js
var TabStateStore = class {
  async init() {
    const raw = await chrome.storage.local.get([STORAGE_KEYS.TAB_STATES, STORAGE_KEYS.ACTIVE_SESSION_BY_TAB]);
    const updates = {};
    if (!raw?.[STORAGE_KEYS.TAB_STATES]) {
      updates[STORAGE_KEYS.TAB_STATES] = {};
    }
    if (!raw?.[STORAGE_KEYS.ACTIVE_SESSION_BY_TAB]) {
      updates[STORAGE_KEYS.ACTIVE_SESSION_BY_TAB] = {};
    }
    if (Object.keys(updates).length > 0) {
      await chrome.storage.local.set(updates);
    }
  }
  async getAllStates() {
    await this.init();
    const raw = await chrome.storage.local.get([STORAGE_KEYS.TAB_STATES]);
    return raw?.[STORAGE_KEYS.TAB_STATES] || {};
  }
  async getState(pageSessionId) {
    const states = await this.getAllStates();
    return states[pageSessionId] || null;
  }
  async upsertState(pageSessionId, patch) {
    const states = await this.getAllStates();
    const previous = states[pageSessionId] || createEmptyState(pageSessionId);
    const next = {
      ...previous,
      ...patch,
      progress: {
        ...previous.progress,
        ...patch.progress || {}
      },
      updatedAt: Date.now()
    };
    states[pageSessionId] = next;
    await chrome.storage.local.set({ [STORAGE_KEYS.TAB_STATES]: states });
    return next;
  }
  async setActiveSession(tabId, pageSessionId) {
    await this.init();
    const raw = await chrome.storage.local.get([STORAGE_KEYS.ACTIVE_SESSION_BY_TAB]);
    const map = raw?.[STORAGE_KEYS.ACTIVE_SESSION_BY_TAB] || {};
    if (pageSessionId) {
      map[String(tabId)] = pageSessionId;
    } else {
      delete map[String(tabId)];
    }
    await chrome.storage.local.set({ [STORAGE_KEYS.ACTIVE_SESSION_BY_TAB]: map });
  }
  async getActiveSessionByTab(tabId) {
    await this.init();
    const raw = await chrome.storage.local.get([STORAGE_KEYS.ACTIVE_SESSION_BY_TAB]);
    const map = raw?.[STORAGE_KEYS.ACTIVE_SESSION_BY_TAB] || {};
    return map[String(tabId)] || null;
  }
  async clearSession(pageSessionId) {
    const states = await this.getAllStates();
    delete states[pageSessionId];
    await chrome.storage.local.set({ [STORAGE_KEYS.TAB_STATES]: states });
    const raw = await chrome.storage.local.get([STORAGE_KEYS.ACTIVE_SESSION_BY_TAB]);
    const map = raw?.[STORAGE_KEYS.ACTIVE_SESSION_BY_TAB] || {};
    for (const [tabId, sessionId] of Object.entries(map)) {
      if (sessionId === pageSessionId) {
        delete map[tabId];
      }
    }
    await chrome.storage.local.set({ [STORAGE_KEYS.ACTIVE_SESSION_BY_TAB]: map });
  }
  async clearAll() {
    await chrome.storage.local.set({
      [STORAGE_KEYS.TAB_STATES]: {},
      [STORAGE_KEYS.ACTIVE_SESSION_BY_TAB]: {}
    });
  }
};
function createEmptyState(pageSessionId) {
  return {
    pageSessionId,
    stage: PIPELINE_STAGE.IDLE,
    tabId: null,
    url: "",
    startedAt: null,
    updatedAt: Date.now(),
    cancelled: false,
    hasTranslatedBlocks: false,
    viewMode: VIEW_MODE.ORIGINAL,
    progress: {
      done: 0,
      pending: 0,
      failed: 0,
      total: 0,
      errorCount: 0
    },
    batches: [],
    batchWindow: {
      previous: [],
      compacted: []
    },
    lastError: null,
    queueSize: 0
  };
}

// src/sw/offscreen-client.js
var OffscreenClient = class {
  constructor() {
    this.ensurePromise = null;
  }
  async ensureDocument() {
    if (this.ensurePromise) {
      return this.ensurePromise;
    }
    this.ensurePromise = (async () => {
      const offscreenUrl = chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH);
      const contexts = await chrome.runtime.getContexts({
        contextTypes: ["OFFSCREEN_DOCUMENT"],
        documentUrls: [offscreenUrl]
      });
      if (contexts.length === 0) {
        await chrome.offscreen.createDocument({
          url: OFFSCREEN_DOCUMENT_PATH,
          reasons: ["WORKERS"],
          justification: "Need stable long-running translation requests independent from service worker lifecycle"
        });
      }
    })();
    await this.ensurePromise;
    this.ensurePromise = null;
  }
  async execute(payload) {
    await this.ensureDocument();
    const response = await chrome.runtime.sendMessage({
      type: MESSAGE.OFFSCREEN_EXECUTE,
      payload
    });
    if (!response?.ok) {
      const error = new Error(response?.error || "Offscreen execution failed");
      error.status = response?.status;
      error.retryAfterMs = response?.retryAfterMs || 0;
      throw error;
    }
    return response.result;
  }
  async cancel(requestId, pageSessionId) {
    await this.ensureDocument();
    const response = await chrome.runtime.sendMessage({
      type: MESSAGE.OFFSCREEN_CANCEL,
      requestId,
      pageSessionId
    });
    return response?.ok ? response.result : null;
  }
};

// src/shared/batching.js
function createBatches({ blocks, pageSessionId, settings }) {
  const target = settings?.batching?.batchTokenTarget ?? 1200;
  const maxBlocks = settings?.batching?.maxBlocksPerBatch ?? 24;
  const blockLimits = settings?.batching?.blockLimits || { minChars: 1, maxChars: 2800 };
  const filtered = blocks.filter((block) => block.text?.trim()?.length >= blockLimits.minChars).map((block) => {
    const text = block.text.slice(0, blockLimits.maxChars);
    return {
      ...block,
      text,
      estimatedTokens: estimateTokens(text)
    };
  });
  const result = [];
  let current = [];
  let currentTokens = 0;
  for (const block of filtered) {
    const wouldExceedTokens = currentTokens + block.estimatedTokens > target;
    const wouldExceedCount = current.length >= maxBlocks;
    if (current.length > 0 && (wouldExceedTokens || wouldExceedCount)) {
      result.push(current);
      current = [];
      currentTokens = 0;
    }
    current.push(block);
    currentTokens += block.estimatedTokens;
  }
  if (current.length > 0) {
    result.push(current);
  }
  return result.map((items, index) => {
    const blockIds = items.map((item) => item.blockId);
    return {
      index,
      batchId: buildBatchId(pageSessionId, index, blockIds),
      blockIds,
      blocks: items,
      tokensEstimate: items.reduce((sum, item) => sum + item.estimatedTokens, 0)
    };
  });
}

// src/shared/batch-window.js
var BatchWindowManager = class {
  constructor(settings) {
    this.prevBatchesCount = settings?.batchWindow?.prevBatchesCount ?? 3;
    this.compactAfter = settings?.batchWindow?.compactAfter ?? settings?.compaction?.thresholds?.startAfterBatch ?? 8;
    this.compactionTokenTarget = Math.max(32, Number(settings?.compaction?.thresholds?.tokenTarget) || 450);
    this.maxCompactions = 20;
    this.compacted = [];
  }
  buildWindow(translatedBatches, index) {
    const start = Math.max(0, index - this.prevBatchesCount);
    return translatedBatches.slice(start, index);
  }
  pushCompactionIfNeeded(translatedBatches, index) {
    if (index < this.compactAfter) {
      return;
    }
    const overflowCount = index - this.prevBatchesCount;
    if (overflowCount <= 0) {
      return;
    }
    const outOfWindow = translatedBatches.slice(0, overflowCount);
    const previous = this.compacted[this.compacted.length - 1] || null;
    const sourceIndexes = previous ? unionIndexes(previous.sourceIndexes, outOfWindow.map((batch) => batch.index)) : outOfWindow.map((batch) => batch.index);
    const candidateParts = [];
    if (previous?.text) {
      candidateParts.push(`PREV_COMPACTION:
${previous.text}`);
    }
    const recentOverflow = outOfWindow.slice(-6);
    for (const batch of recentOverflow) {
      candidateParts.push(`${batch.batchId}: ${batch.summary || batch.joinedText || ""}`);
    }
    const candidateText = candidateParts.join("\n");
    const compactedText = clampTextByTokens(candidateText, this.compactionTokenTarget);
    const tokenEstimate = estimateTokens(compactedText);
    if (!compactedText.trim()) {
      return;
    }
    if (previous && previous.text === compactedText) {
      return;
    }
    this.compacted.push({
      sourceIndexes,
      text: compactedText,
      tokenEstimate
    });
    if (this.compacted.length > this.maxCompactions) {
      this.compacted.splice(0, this.compacted.length - this.maxCompactions);
    }
  }
  getCompactionContext() {
    return this.compacted.slice(-3);
  }
};
function clampTextByTokens(text, tokenTarget) {
  if (!text) {
    return "";
  }
  if (estimateTokens(text) <= tokenTarget) {
    return text;
  }
  const maxChars = tokenTarget * 4;
  return text.slice(-maxChars);
}
function unionIndexes(left, right) {
  const set = /* @__PURE__ */ new Set([...left || [], ...right || []]);
  return [...set].sort((a, b) => a - b);
}

// src/shared/cancellation-registry.js
var CancellationRegistry = class {
  constructor() {
    this.bySession = /* @__PURE__ */ new Map();
  }
  createSession(pageSessionId) {
    const controller = new AbortController();
    this.bySession.set(pageSessionId, {
      controller,
      requestIds: /* @__PURE__ */ new Set()
    });
    return controller.signal;
  }
  getSignal(pageSessionId) {
    return this.bySession.get(pageSessionId)?.controller.signal || null;
  }
  registerRequest(pageSessionId, requestId) {
    const session = this.bySession.get(pageSessionId);
    if (!session) {
      return;
    }
    session.requestIds.add(requestId);
  }
  unregisterRequest(pageSessionId, requestId) {
    const session = this.bySession.get(pageSessionId);
    if (!session) {
      return;
    }
    session.requestIds.delete(requestId);
  }
  cancelSession(pageSessionId) {
    const session = this.bySession.get(pageSessionId);
    if (!session) {
      return { requestIds: [] };
    }
    session.controller.abort();
    const requestIds = [...session.requestIds];
    this.bySession.delete(pageSessionId);
    return { requestIds };
  }
  clearSession(pageSessionId) {
    this.bySession.delete(pageSessionId);
  }
};

// src/shared/inflight-request-store.js
var InflightRequestStore = class {
  constructor({ storageKey = "inflightRequestMeta", maxRecords = 500 } = {}) {
    this.requests = /* @__PURE__ */ new Map();
    this.storageKey = storageKey;
    this.maxRecords = maxRecords;
    this.flushTimer = null;
    this.initialized = false;
  }
  async init() {
    if (this.initialized) {
      return;
    }
    this.initialized = true;
    if (!globalThis.chrome?.storage?.local) {
      return;
    }
    try {
      const raw = await chrome.storage.local.get([this.storageKey]);
      const rows = Array.isArray(raw?.[this.storageKey]) ? raw[this.storageKey] : [];
      for (const row of rows) {
        if (!row?.requestId) {
          continue;
        }
        this.requests.set(row.requestId, {
          ...row,
          startedAt: Number(row.startedAt) || Date.now()
        });
      }
    } catch {
    }
  }
  add(meta) {
    if (!meta?.requestId) {
      return;
    }
    this.requests.set(meta.requestId, {
      ...meta,
      startedAt: Date.now()
    });
    this.scheduleFlush();
  }
  remove(requestId) {
    if (!requestId) {
      return;
    }
    this.requests.delete(requestId);
    this.scheduleFlush();
  }
  clearSession(pageSessionId) {
    if (!pageSessionId) {
      return;
    }
    let changed = false;
    for (const [requestId, request] of this.requests.entries()) {
      if (request.pageSessionId === pageSessionId) {
        this.requests.delete(requestId);
        changed = true;
      }
    }
    if (changed) {
      this.scheduleFlush();
    }
  }
  listBySession(pageSessionId) {
    return [...this.requests.values()].filter((item) => item.pageSessionId === pageSessionId);
  }
  list() {
    return [...this.requests.values()];
  }
  clear() {
    this.requests.clear();
    this.scheduleFlush();
  }
  scheduleFlush() {
    if (!globalThis.chrome?.storage?.local) {
      return;
    }
    clearTimeout(this.flushTimer);
    this.flushTimer = setTimeout(() => {
      this.flush().catch(() => {
      });
    }, 40);
  }
  async flush() {
    if (!globalThis.chrome?.storage?.local) {
      return;
    }
    const rows = [...this.requests.values()].sort((left, right) => (left.startedAt || 0) - (right.startedAt || 0)).slice(-this.maxRecords);
    await chrome.storage.local.set({ [this.storageKey]: rows });
  }
};

// src/shared/job-queue.js
var JobQueue = class {
  constructor({ concurrency = 1 } = {}) {
    this.concurrency = concurrency;
    this.active = 0;
    this.queue = [];
    this.stopped = false;
    this.idCounter = 0;
  }
  push(run) {
    if (this.stopped) {
      return Promise.reject(new Error("Queue stopped"));
    }
    const jobId = `job_${++this.idCounter}`;
    return new Promise((resolve, reject) => {
      this.queue.push({ jobId, run, resolve, reject });
      this.flush();
    });
  }
  flush() {
    if (this.stopped) {
      return;
    }
    while (this.active < this.concurrency && this.queue.length > 0) {
      const item = this.queue.shift();
      this.active += 1;
      Promise.resolve().then(() => item.run()).then(item.resolve).catch(item.reject).finally(() => {
        this.active -= 1;
        this.flush();
      });
    }
  }
  setConcurrency(nextConcurrency) {
    this.concurrency = Math.max(1, nextConcurrency);
    this.flush();
  }
  clearPending(error = new Error("Queue cleared")) {
    const pending = this.queue.splice(0, this.queue.length);
    for (const item of pending) {
      item.reject(error);
    }
  }
  stop(error = new Error("Queue stopped")) {
    this.stopped = true;
    this.clearPending(error);
  }
  size() {
    return this.queue.length;
  }
};

// src/shared/rate-limit-controller.js
var RateLimitError = class extends Error {
  constructor(message, { retryAfterMs = 0, status = 429 } = {}) {
    super(message);
    this.name = "RateLimitError";
    this.retryAfterMs = retryAfterMs;
    this.status = status;
  }
};
var BudgetThroughputController = class {
  constructor({ modelLimits = {}, roleModelLimits = {}, safetyBufferTokens = 500, logger = null } = {}) {
    this.modelLimits = modelLimits;
    this.roleModelLimits = roleModelLimits;
    this.safetyBufferTokens = safetyBufferTokens;
    this.logger = logger;
    this.state = /* @__PURE__ */ new Map();
  }
  resolveLimits(model, role) {
    const byRole = this.roleModelLimits?.[role];
    if (byRole && byRole[model]) {
      return byRole[model];
    }
    return this.modelLimits[model] || { tpm: 6e4, rpm: 300, concurrency: 2 };
  }
  buildStateKey(model, role) {
    return `${role}:${model}`;
  }
  ensureModelState(model, role = "translation") {
    const stateKey = this.buildStateKey(model, role);
    if (!this.state.has(stateKey)) {
      const limits = this.resolveLimits(model, role);
      this.state.set(stateKey, {
        stateKey,
        role,
        model,
        limits,
        dynamicConcurrency: limits.concurrency,
        active: 0,
        tokenWindow: [],
        requestWindow: [],
        lastRateLimitAt: 0,
        consecutiveSuccesses: 0
      });
    }
    return this.state.get(stateKey);
  }
  prune(modelState, nowMs) {
    const oneMinuteAgo = nowMs - 6e4;
    modelState.tokenWindow = modelState.tokenWindow.filter((item) => item.ts >= oneMinuteAgo);
    modelState.requestWindow = modelState.requestWindow.filter((ts) => ts >= oneMinuteAgo);
  }
  estimateWaitMs(modelState, nowMs, tokensEstimate) {
    const { tpm, rpm } = modelState.limits;
    const concurrency = Math.max(1, Number(modelState.dynamicConcurrency) || 1);
    if (modelState.active >= concurrency) {
      return 100;
    }
    const usedTokens = modelState.tokenWindow.reduce((sum, item) => sum + item.tokens, 0);
    if (usedTokens + tokensEstimate + this.safetyBufferTokens > tpm) {
      const earliest = modelState.tokenWindow[0]?.ts;
      if (earliest) {
        return Math.max(100, earliest + 6e4 - nowMs);
      }
    }
    if (modelState.requestWindow.length >= rpm) {
      const earliestReq = modelState.requestWindow[0];
      return Math.max(100, earliestReq + 6e4 - nowMs);
    }
    return 0;
  }
  async acquire(model, tokensEstimate, { signal, role = "translation" } = {}) {
    const modelState = this.ensureModelState(model, role);
    while (true) {
      if (signal?.aborted) {
        throw new DOMException("Request aborted", "AbortError");
      }
      const nowMs = Date.now();
      this.prune(modelState, nowMs);
      const waitMs = this.estimateWaitMs(modelState, nowMs, tokensEstimate);
      if (waitMs <= 0) {
        modelState.active += 1;
        modelState.requestWindow.push(nowMs);
        modelState.tokenWindow.push({ ts: nowMs, tokens: tokensEstimate });
        return;
      }
      this.logger?.({
        name: "rate_limit_wait",
        model,
        role,
        waitMs,
        tokensEstimate
      });
      await sleep(Math.min(waitMs, 1500));
    }
  }
  release(model, { role = "translation" } = {}) {
    const modelState = this.ensureModelState(model, role);
    modelState.active = Math.max(0, modelState.active - 1);
  }
  noteRateLimit(model, { role = "translation" } = {}) {
    const modelState = this.ensureModelState(model, role);
    modelState.lastRateLimitAt = Date.now();
    modelState.consecutiveSuccesses = 0;
    modelState.dynamicConcurrency = Math.max(1, (modelState.dynamicConcurrency || modelState.limits.concurrency) - 1);
    this.logger?.({
      name: "rate_limit_concurrency_down",
      model,
      role,
      dynamicConcurrency: modelState.dynamicConcurrency
    });
  }
  noteSuccess(model, { role = "translation" } = {}) {
    const modelState = this.ensureModelState(model, role);
    modelState.consecutiveSuccesses += 1;
    const target = Math.max(1, modelState.limits.concurrency);
    const now = Date.now();
    const coolDownPassed = now - (modelState.lastRateLimitAt || 0) > 3e4;
    if (coolDownPassed && modelState.dynamicConcurrency < target && modelState.consecutiveSuccesses >= 4) {
      modelState.dynamicConcurrency += 1;
      modelState.consecutiveSuccesses = 0;
      this.logger?.({
        name: "rate_limit_concurrency_up",
        model,
        role,
        dynamicConcurrency: modelState.dynamicConcurrency
      });
    }
  }
  getSnapshot(model, { role = "translation" } = {}) {
    const modelState = this.ensureModelState(model, role);
    return {
      limits: { ...modelState.limits },
      role: modelState.role,
      model: modelState.model,
      dynamicConcurrency: modelState.dynamicConcurrency,
      active: modelState.active,
      lastRateLimitAt: modelState.lastRateLimitAt,
      consecutiveSuccesses: modelState.consecutiveSuccesses
    };
  }
  async runWithBudget({ model, role = "translation", tokensEstimate, fn, signal, onRateLimit }) {
    await this.acquire(model, tokensEstimate, { signal, role });
    try {
      const result = await fn();
      this.noteSuccess(model, { role });
      return result;
    } catch (error) {
      if (error instanceof RateLimitError) {
        this.noteRateLimit(model, { role });
        if (typeof onRateLimit === "function") {
          onRateLimit(error);
        }
      }
      throw error;
    } finally {
      this.release(model, { role });
    }
  }
  async retryWithBackoff(task, {
    maxAttempts = 5,
    minDelayMs = 500,
    maxDelayMs = 3e4,
    jitterMs = 350,
    signal,
    onAttempt,
    shouldRetry
  } = {}) {
    let attempt = 0;
    let delayMs = minDelayMs;
    while (attempt < maxAttempts) {
      if (signal?.aborted) {
        throw new DOMException("Request aborted", "AbortError");
      }
      attempt += 1;
      try {
        return await task(attempt);
      } catch (error) {
        const retry = shouldRetry ? shouldRetry(error) : error instanceof RateLimitError;
        if (!retry || attempt >= maxAttempts) {
          throw error;
        }
        const retryAfterMs = error?.retryAfterMs || 0;
        const randomJitter = Math.floor(Math.random() * jitterMs);
        const sleepMs = Math.min(maxDelayMs, Math.max(delayMs, retryAfterMs) + randomJitter);
        onAttempt?.({ attempt, sleepMs, error });
        await sleep(sleepMs);
        delayMs = Math.min(maxDelayMs, delayMs * 2);
      }
    }
    throw new Error("Retry budget exhausted");
  }
};

// src/shared/translation-schema.js
var REQUIRED_TRANSLATION_KEYS = ["batchId", "translations"];
var TOP_LEVEL_KEYS = /* @__PURE__ */ new Set(["batchId", "sourceLang", "targetLang", "glossaryHints", "qualityFlags", "translations"]);
var ROW_KEYS = /* @__PURE__ */ new Set(["blockId", "translatedText", "warnings"]);
var TRANSLATION_JSON_SCHEMA = Object.freeze({
  type: "object",
  additionalProperties: false,
  required: REQUIRED_TRANSLATION_KEYS,
  properties: {
    batchId: { type: "string" },
    sourceLang: { type: "string" },
    targetLang: { type: "string" },
    glossaryHints: { type: "array", items: { type: "string" } },
    qualityFlags: { type: "array", items: { type: "string" } },
    translations: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["blockId", "translatedText"],
        properties: {
          blockId: { type: "string" },
          translatedText: { type: "string" },
          warnings: { type: "array", items: { type: "string" } }
        }
      }
    }
  }
});
function validateStructuredTranslation(payload) {
  if (!payload || typeof payload !== "object") {
    throw new Error("Structured output must be an object");
  }
  for (const key of Object.keys(payload)) {
    if (!TOP_LEVEL_KEYS.has(key)) {
      throw new Error(`Structured output contains unsupported key: ${key}`);
    }
  }
  for (const key of REQUIRED_TRANSLATION_KEYS) {
    if (!(key in payload)) {
      throw new Error(`Structured output missing key: ${key}`);
    }
  }
  if (typeof payload.batchId !== "string" || !payload.batchId) {
    throw new Error("Structured output batchId must be a non-empty string");
  }
  if (payload.sourceLang !== void 0 && typeof payload.sourceLang !== "string") {
    throw new Error("Structured output sourceLang must be a string");
  }
  if (payload.targetLang !== void 0 && typeof payload.targetLang !== "string") {
    throw new Error("Structured output targetLang must be a string");
  }
  if (payload.glossaryHints !== void 0) {
    if (!Array.isArray(payload.glossaryHints) || payload.glossaryHints.some((item) => typeof item !== "string")) {
      throw new Error("Structured output glossaryHints must be an array of strings");
    }
  }
  if (payload.qualityFlags !== void 0) {
    if (!Array.isArray(payload.qualityFlags) || payload.qualityFlags.some((item) => typeof item !== "string")) {
      throw new Error("Structured output qualityFlags must be an array of strings");
    }
  }
  if (!Array.isArray(payload.translations)) {
    throw new Error("Structured output translations must be an array");
  }
  for (const row of payload.translations) {
    if (!row || typeof row !== "object") {
      throw new Error("Each translation row must be an object");
    }
    for (const key of Object.keys(row)) {
      if (!ROW_KEYS.has(key)) {
        throw new Error(`Translation row contains unsupported key: ${key}`);
      }
    }
    if (typeof row.blockId !== "string" || !row.blockId) {
      throw new Error("Translation row missing blockId");
    }
    if (typeof row.translatedText !== "string") {
      throw new Error("Translation row missing translatedText");
    }
    if (row.warnings !== void 0) {
      if (!Array.isArray(row.warnings) || row.warnings.some((item) => typeof item !== "string")) {
        throw new Error("Translation row warnings must be an array of strings");
      }
    }
  }
  return payload;
}

// src/sw/pipeline-orchestrator.js
var PipelineOrchestrator = class {
  constructor({ settingsStore: settingsStore2, tabStateStore: tabStateStore2, eventLogStore: eventLogStore2, offscreenClient: offscreenClient2, onStateChanged }) {
    this.settingsStore = settingsStore2;
    this.tabStateStore = tabStateStore2;
    this.eventLogStore = eventLogStore2;
    this.offscreenClient = offscreenClient2;
    this.onStateChanged = onStateChanged;
    this.running = /* @__PURE__ */ new Map();
    this.queues = /* @__PURE__ */ new Map();
    this.cancellation = new CancellationRegistry();
    this.inflightRequests = new InflightRequestStore();
    this.controllerBySession = /* @__PURE__ */ new Map();
    this.uiErrorsByTab = /* @__PURE__ */ new Map();
  }
  async init() {
    await this.settingsStore.init();
    await this.tabStateStore.init();
    await this.inflightRequests.init();
    await this.runGc();
    await chrome.alarms.create(ALARM_RESUME_PIPELINE, { periodInMinutes: 1 });
  }
  async runGc() {
    const settings = await this.settingsStore.getSettings();
    this.eventLogStore.maxRecords = settings.storagePolicy.maxRecords;
    this.eventLogStore.maxAgeMs = settings.storagePolicy.maxAgeMs;
    this.eventLogStore.maxBytes = settings.storagePolicy.maxBytes;
    const result = await this.eventLogStore.gc();
    await this.log({
      level: result.removed > 0 ? LOG_LEVEL.INFO : LOG_LEVEL.DEBUG,
      category: EVENT_CATEGORY.STORAGE_GC,
      name: "event_log_gc",
      data: result
    });
  }
  async startForTab({ tabId, url }) {
    try {
      const resolvedUrl = await this.validateStartRequest(tabId, url);
      url = resolvedUrl;
      this.uiErrorsByTab.delete(String(tabId));
    } catch (error) {
      this.uiErrorsByTab.set(String(tabId), error?.message || "Cannot start translation");
      await this.log({
        level: LOG_LEVEL.ERROR,
        category: EVENT_CATEGORY.ERROR,
        name: "start_rejected",
        tabId,
        error: asErrorObject(error)
      });
      return this.getUiState(tabId);
    }
    const existingSession = await this.tabStateStore.getActiveSessionByTab(tabId);
    if (existingSession && this.running.has(existingSession)) {
      return this.getUiState(tabId);
    }
    const settings = await this.settingsStore.getSettings();
    if (!settings?.mockMode?.enabled && !this.hasAccessCredentials(settings)) {
      this.uiErrorsByTab.set(String(tabId), "Set BYOK API key or PROXY token in Settings");
      await this.log({
        level: LOG_LEVEL.WARN,
        category: EVENT_CATEGORY.UI_ACTION,
        name: "start_blocked_missing_credentials",
        tabId,
        data: {
          accessMode: settings.accessMode
        }
      });
      return this.getUiState(tabId);
    }
    const pageSessionId = buildPageSessionId({ tabId, url, nonce: crypto.randomUUID() });
    const signal = this.cancellation.createSession(pageSessionId);
    const controller = new BudgetThroughputController({
      modelLimits: settings.rateLimits.perModel,
      safetyBufferTokens: settings.rateLimits.safetyBufferTokens,
      logger: (data) => {
        this.log({
          level: LOG_LEVEL.INFO,
          category: EVENT_CATEGORY.OPENAI_RATE_LIMIT,
          name: "throughput_wait",
          pageSessionId,
          tabId,
          data
        });
      }
    });
    this.controllerBySession.set(pageSessionId, controller);
    const queueConcurrency = Math.max(1, settings.rateLimits.perModel[settings.modelPriority.translation[0]]?.concurrency || 1);
    const queue = new JobQueue({ concurrency: queueConcurrency });
    this.queues.set(pageSessionId, queue);
    await this.tabStateStore.setActiveSession(tabId, pageSessionId);
    await this.tabStateStore.upsertState(pageSessionId, {
      tabId,
      url,
      stage: PIPELINE_STAGE.SCANNING,
      startedAt: Date.now(),
      cancelled: false,
      hasTranslatedBlocks: false,
      viewMode: VIEW_MODE.TRANSLATION,
      progress: {
        done: 0,
        pending: 0,
        failed: 0,
        total: 0,
        errorCount: 0
      }
    });
    try {
      await this.sendTabMessageStrict(tabId, {
        type: MESSAGE.CONTENT_SWITCH_VIEW,
        mode: VIEW_MODE.TRANSLATION
      });
    } catch {
    }
    await this.log({
      category: EVENT_CATEGORY.UI_ACTION,
      name: "start_translation",
      pageSessionId,
      tabId,
      data: { url }
    });
    await this.notifyState(tabId);
    const runPromise = this.executePipeline({ pageSessionId, tabId, url, signal, settings }).catch((error) => {
      if (error?.name === "AbortError") {
        return;
      }
      return this.failSession({ pageSessionId, tabId, error });
    }).finally(async () => {
      this.running.delete(pageSessionId);
      this.queues.delete(pageSessionId);
      this.controllerBySession.delete(pageSessionId);
      this.cancellation.clearSession(pageSessionId);
      this.inflightRequests.clearSession(pageSessionId);
      await this.notifyState(tabId);
    });
    this.running.set(pageSessionId, runPromise);
    return this.getUiState(tabId);
  }
  async validateStartRequest(tabId, urlHint) {
    if (!Number.isInteger(tabId) || tabId <= 0) {
      throw new Error("No active tab selected");
    }
    const tab = await chrome.tabs.get(tabId);
    const url = String(tab?.url || urlHint || "").trim();
    if (!/^https?:/i.test(url)) {
      throw new Error("Translation can run only on http/https pages");
    }
    await this.ensureContentScriptReady(tabId);
    return url;
  }
  async ensureContentScriptReady(tabId) {
    const pingPayload = { type: MESSAGE.UI_PING };
    try {
      await this.sendTabMessageStrict(tabId, pingPayload);
      return;
    } catch {
    }
    await chrome.scripting.insertCSS({
      target: { tabId },
      files: ["content/content.css"]
    });
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content/content.js"]
    });
    await this.sendTabMessageStrict(tabId, pingPayload);
  }
  async executePipeline({ pageSessionId, tabId, signal, settings }) {
    await this.updateStage(pageSessionId, tabId, PIPELINE_STAGE.SCANNING);
    const scanResult = await this.sendTabMessageStrict(tabId, {
      type: MESSAGE.CONTENT_SCAN,
      pageSessionId,
      tabId
    });
    await this.throwIfCancelled(signal);
    const blocks = scanResult.blocks || [];
    await this.log({
      category: EVENT_CATEGORY.DOM_SCAN,
      name: "scan_complete",
      pageSessionId,
      tabId,
      data: { blocks: blocks.length }
    });
    await this.tabStateStore.upsertState(pageSessionId, {
      progress: {
        total: blocks.length,
        pending: blocks.length,
        done: 0,
        failed: 0,
        errorCount: 0
      }
    });
    await this.notifyState(tabId);
    if (blocks.length === 0) {
      await this.updateStage(pageSessionId, tabId, PIPELINE_STAGE.DONE);
      await this.log({
        level: LOG_LEVEL.WARN,
        category: EVENT_CATEGORY.PIPELINE_STAGE,
        name: "pipeline_no_blocks",
        pageSessionId,
        tabId,
        data: { blocks: 0 }
      });
      await this.notifyState(tabId);
      return;
    }
    await this.throwIfCancelled(signal);
    await this.updateStage(pageSessionId, tabId, PIPELINE_STAGE.CONTEXT);
    const globalContext = await this.generateGlobalContext({
      pageSessionId,
      tabId,
      settings,
      blocks,
      signal
    });
    await this.throwIfCancelled(signal);
    await this.updateStage(pageSessionId, tabId, PIPELINE_STAGE.BATCHING);
    const batches = createBatches({
      blocks,
      pageSessionId,
      settings
    });
    await this.throwIfCancelled(signal);
    await this.tabStateStore.upsertState(pageSessionId, {
      stage: PIPELINE_STAGE.BATCHING,
      batches: batches.map((batch) => ({
        batchId: batch.batchId,
        index: batch.index,
        status: "pending",
        size: batch.blocks.length,
        tokensEstimate: batch.tokensEstimate
      })),
      progress: {
        total: batches.length,
        pending: batches.length,
        done: 0,
        failed: 0
      }
    });
    await this.log({
      category: EVENT_CATEGORY.BATCH_CREATE,
      name: "batches_created",
      pageSessionId,
      tabId,
      data: {
        batchCount: batches.length,
        avgBlocksPerBatch: batches.length > 0 ? Number((batches.reduce((acc, batch) => acc + batch.blocks.length, 0) / batches.length).toFixed(2)) : 0
      }
    });
    await this.notifyState(tabId);
    await this.updateStage(pageSessionId, tabId, PIPELINE_STAGE.TRANSLATING);
    const translatedBatches = [];
    const windowManager = new BatchWindowManager(settings);
    const batchJobs = [];
    const queue = this.queues.get(pageSessionId);
    if (!queue) {
      throw new Error("Pipeline queue is not available");
    }
    for (const batch of batches) {
      await this.throwIfCancelled(signal);
      batchJobs.push(queue.push(async () => {
        const result = await this.translateSingleBatch({
          pageSessionId,
          tabId,
          settings,
          globalContext,
          batch,
          translatedBatches,
          windowManager,
          signal
        });
        translatedBatches.push(result);
      }));
    }
    await Promise.all(batchJobs);
    await this.waitQueueIdle(pageSessionId);
    await this.throwIfCancelled(signal);
    await this.updateStage(pageSessionId, tabId, PIPELINE_STAGE.DONE);
    await this.tabStateStore.upsertState(pageSessionId, {
      hasTranslatedBlocks: translatedBatches.length > 0,
      progress: {
        done: translatedBatches.length,
        pending: 0
      }
    });
    await this.log({
      category: EVENT_CATEGORY.PIPELINE_STAGE,
      name: "pipeline_done",
      pageSessionId,
      tabId,
      data: { batches: translatedBatches.length }
    });
    await this.notifyState(tabId);
  }
  async translateSingleBatch({
    pageSessionId,
    tabId,
    settings,
    globalContext,
    batch,
    translatedBatches,
    windowManager,
    signal
  }) {
    const controller = this.controllerBySession.get(pageSessionId);
    if (!controller) {
      throw new Error("Throughput controller is not available");
    }
    const model = settings.modelPriority.translation[0] || settings.globalContext.model;
    const previousWindow = windowManager.buildWindow(translatedBatches, batch.index);
    windowManager.pushCompactionIfNeeded(translatedBatches, batch.index);
    const payload = {
      role: "translation",
      model,
      promptCaching: settings.promptCaching,
      mockMode: settings.mockMode,
      pageSessionId,
      batchId: batch.batchId,
      input: {
        globalContext,
        previousWindow,
        compactedHistory: windowManager.getCompactionContext(),
        compactionPolicy: settings.compaction,
        blocks: batch.blocks.map((item) => ({
          blockId: item.blockId,
          text: item.text,
          category: item.category
        }))
      },
      schema: "translation"
    };
    const serializedInput = JSON.stringify(payload.input);
    const tokensEstimate = estimateTokens(serializedInput) + 800;
    const requestId = `req_${stableHash(`${pageSessionId}_${batch.batchId}_${Date.now()}`)}`;
    this.cancellation.registerRequest(pageSessionId, requestId);
    this.inflightRequests.add({ requestId, pageSessionId, tabId, batchId: batch.batchId, model, kind: "translation" });
    await this.log({
      category: EVENT_CATEGORY.OPENAI_REQUEST,
      name: "translation_request_sent",
      pageSessionId,
      tabId,
      batchId: batch.batchId,
      data: {
        requestId,
        model,
        tokensEstimate,
        promptCachingEnabled: settings.promptCaching.enabled
      }
    });
    let raw;
    try {
      raw = await controller.retryWithBackoff(
        async (attempt) => {
          await this.throwIfCancelled(signal);
          const response = await controller.runWithBudget({
            model,
            role: "translation",
            tokensEstimate,
            signal,
            onRateLimit: (error) => {
              this.syncQueueConcurrency(pageSessionId, model);
              this.log({
                level: LOG_LEVEL.WARN,
                category: EVENT_CATEGORY.OPENAI_RATE_LIMIT,
                name: "rate_limit_hit",
                pageSessionId,
                tabId,
                batchId: batch.batchId,
                data: {
                  requestId,
                  retryAfterMs: error.retryAfterMs,
                  status: error.status,
                  attempt
                }
              });
            },
            fn: () => this.offscreenClient.execute({
              requestId,
              pageSessionId,
              tabId,
              operation: "openai.responses",
              payload,
              access: this.buildAccess(settings)
            }).catch((error) => {
              if (Number(error?.status) === 429) {
                throw new RateLimitError(error.message, {
                  retryAfterMs: error?.retryAfterMs || 1e3,
                  status: 429
                });
              }
              throw error;
            })
          });
          this.syncQueueConcurrency(pageSessionId, model);
          return response;
        },
        {
          signal,
          maxAttempts: 6,
          onAttempt: ({ attempt, sleepMs, error }) => {
            this.log({
              level: LOG_LEVEL.WARN,
              category: EVENT_CATEGORY.OPENAI_RATE_LIMIT,
              name: "retry_backoff",
              pageSessionId,
              tabId,
              batchId: batch.batchId,
              data: {
                attempt,
                sleepMs,
                reason: error?.message || "unknown"
              }
            });
          },
          shouldRetry: (error) => {
            if (error?.name === "AbortError") {
              return false;
            }
            if (error instanceof RateLimitError) {
              return true;
            }
            const status = Number(error?.status || 0);
            return status === 429 || status >= 500 && status < 600;
          }
        }
      );
    } finally {
      this.cancellation.unregisterRequest(pageSessionId, requestId);
      this.inflightRequests.remove(requestId);
    }
    const translation = validateStructuredTranslation(raw.structured);
    await this.throwIfCancelled(signal);
    if (translation.batchId !== batch.batchId) {
      throw new Error(`Batch mismatch: expected ${batch.batchId}, got ${translation.batchId}`);
    }
    const applyPayload = {
      batchId: batch.batchId,
      translations: translation.translations
    };
    await this.sendTabMessageStrict(tabId, {
      type: MESSAGE.CONTENT_APPLY_BATCH,
      pageSessionId,
      tabId,
      payload: applyPayload
    });
    await this.throwIfCancelled(signal);
    const currentState = await this.tabStateStore.getState(pageSessionId);
    const done = (currentState?.progress?.done || 0) + 1;
    const failed = currentState?.progress?.failed || 0;
    const total = currentState?.progress?.total || 0;
    const pending = Math.max(0, total - done - failed);
    await this.tabStateStore.upsertState(pageSessionId, {
      hasTranslatedBlocks: true,
      progress: {
        done,
        pending,
        failed,
        total
      }
    });
    await this.log({
      category: EVENT_CATEGORY.OPENAI_RESPONSE,
      name: "translation_response_ok",
      pageSessionId,
      tabId,
      batchId: batch.batchId,
      data: {
        requestId,
        translationRows: translation.translations.length,
        usage: raw?.usage || null
      }
    });
    await this.log({
      category: EVENT_CATEGORY.BATCH_TRANSLATE,
      name: "batch_translated",
      pageSessionId,
      tabId,
      batchId: batch.batchId,
      data: {
        progressDone: done,
        progressTotal: total
      }
    });
    await this.notifyState(tabId);
    return {
      index: batch.index,
      batchId: batch.batchId,
      joinedText: translation.translations.map((row) => row.translatedText).join("\n")
    };
  }
  async generateGlobalContext({ pageSessionId, tabId, settings, blocks, signal }) {
    const model = settings.modelPriority.context[0] || settings.globalContext.model;
    const targetTokens = Math.max(15e3, Number(settings.globalContext.targetTokens) || 15e3);
    const maxOutputTokens = Math.max(512, Number(settings.globalContext.maxOutputTokens) || 4096);
    const minPasses = Math.max(1, Math.ceil(targetTokens / maxOutputTokens));
    const blockChunks = buildContextChunks(blocks, 6e3);
    const passCount = Math.max(minPasses, blockChunks.length);
    const controller = this.controllerBySession.get(pageSessionId);
    const contextParts = [];
    let mergedTokens = 0;
    for (let passIndex = 0; passIndex < passCount; passIndex += 1) {
      await this.throwIfCancelled(signal);
      if (mergedTokens >= targetTokens && passIndex >= minPasses) {
        break;
      }
      const chunk = blockChunks[passIndex % blockChunks.length];
      const orderedBlocks = chunk.map((block) => `[${block.blockId}] (${block.category}) ${block.text}`).join("\n");
      const previousContextTail = contextParts.join("\n").slice(-16e3);
      const payload = {
        role: "context",
        model,
        promptCaching: settings.promptCaching,
        mockMode: settings.mockMode,
        pageSessionId,
        input: {
          targetTokens,
          maxOutputTokens,
          passIndex,
          passCount,
          previousContextTail,
          instruction: "Build a detailed global translation context for this page. Preserve entities, style, product names, legal terminology, and consistency constraints.",
          orderedBlocks
        },
        schema: "context"
      };
      const requestId = `req_${stableHash(`${pageSessionId}_context_${passIndex}_${Date.now()}`)}`;
      this.cancellation.registerRequest(pageSessionId, requestId);
      this.inflightRequests.add({ requestId, pageSessionId, tabId, model, kind: "context" });
      await this.log({
        category: EVENT_CATEGORY.OPENAI_REQUEST,
        name: "context_request_sent",
        pageSessionId,
        tabId,
        data: {
          requestId,
          model,
          targetTokens,
          maxOutputTokens,
          passIndex,
          passCount,
          chunkBlocks: chunk.length
        }
      });
      let response;
      try {
        response = await controller.retryWithBackoff(
          async (attempt) => controller.runWithBudget({
            model,
            role: "context",
            tokensEstimate: estimateTokens(orderedBlocks) + maxOutputTokens + estimateTokens(previousContextTail),
            signal,
            onRateLimit: (error) => {
              this.log({
                level: LOG_LEVEL.WARN,
                category: EVENT_CATEGORY.OPENAI_RATE_LIMIT,
                name: "context_rate_limit_hit",
                pageSessionId,
                tabId,
                data: {
                  requestId,
                  retryAfterMs: error.retryAfterMs,
                  status: error.status,
                  attempt
                }
              });
            },
            fn: () => this.offscreenClient.execute({
              requestId,
              pageSessionId,
              tabId,
              operation: "openai.responses",
              payload,
              access: this.buildAccess(settings)
            }).catch((error) => {
              if (Number(error?.status) === 429) {
                throw new RateLimitError(error.message, {
                  retryAfterMs: error?.retryAfterMs || 1e3,
                  status: 429
                });
              }
              throw error;
            })
          }).catch((error) => {
            if (error instanceof RateLimitError) {
              throw error;
            }
            const retryAfterMs = parseRetryAfterSeconds(error?.headers);
            if (Number(error?.status) === 429) {
              throw new RateLimitError(error.message, {
                retryAfterMs: retryAfterMs ? retryAfterMs * 1e3 : 1e3,
                status: 429
              });
            }
            throw error;
          }),
          {
            signal,
            maxAttempts: 5,
            onAttempt: ({ attempt, sleepMs, error }) => {
              this.log({
                level: LOG_LEVEL.WARN,
                category: EVENT_CATEGORY.OPENAI_RATE_LIMIT,
                name: "context_retry_backoff",
                pageSessionId,
                tabId,
                data: {
                  requestId,
                  attempt,
                  sleepMs,
                  reason: error?.message || "unknown"
                }
              });
            },
            shouldRetry: (error) => {
              if (error?.name === "AbortError") {
                return false;
              }
              if (error instanceof RateLimitError) {
                return true;
              }
              const status = Number(error?.status || 0);
              return status === 429 || status >= 500 && status < 600;
            }
          }
        );
      } finally {
        this.cancellation.unregisterRequest(pageSessionId, requestId);
        this.inflightRequests.remove(requestId);
      }
      const contextText = String(response?.structured?.context || response?.text || "").trim();
      if (contextText) {
        contextParts.push(`[pass ${passIndex + 1}/${passCount}]
${contextText}`);
      }
      mergedTokens = estimateTokens(contextParts.join("\n\n"));
      await this.log({
        category: EVENT_CATEGORY.CONTEXT_GENERATE,
        name: "context_pass_ready",
        pageSessionId,
        tabId,
        data: {
          requestId,
          passIndex,
          passCount,
          mergedTokens,
          usage: response?.usage || null
        }
      });
    }
    const mergedText = contextParts.join("\n\n");
    const tokensApprox = estimateTokens(mergedText);
    if (tokensApprox < targetTokens) {
      await this.log({
        level: LOG_LEVEL.WARN,
        category: EVENT_CATEGORY.CONTEXT_GENERATE,
        name: "global_context_target_not_reached",
        pageSessionId,
        tabId,
        data: {
          tokensApprox,
          targetTokens,
          passCount: contextParts.length
        }
      });
    }
    await this.log({
      category: EVENT_CATEGORY.CONTEXT_GENERATE,
      name: "global_context_ready",
      pageSessionId,
      tabId,
      data: {
        tokensApprox,
        targetTokens,
        passCount: contextParts.length
      }
    });
    return {
      text: mergedText,
      model,
      targetTokens
    };
  }
  buildAccess(settings) {
    if (settings.accessMode === "PROXY") {
      return {
        mode: "PROXY",
        baseUrl: settings.proxyBaseUrl,
        token: settings.proxyToken
      };
    }
    return {
      mode: "BYOK",
      baseUrl: settings.byokBaseUrl,
      apiKey: settings.byokApiKey
    };
  }
  hasAccessCredentials(settings) {
    if (settings.accessMode === "PROXY") {
      return Boolean(settings.proxyToken && settings.proxyBaseUrl);
    }
    return Boolean(settings.byokApiKey && settings.byokBaseUrl);
  }
  async hardCancel({ tabId, reason = "ui_cancel" }) {
    const pageSessionId = await this.tabStateStore.getActiveSessionByTab(tabId);
    if (!pageSessionId) {
      return this.getUiState(tabId);
    }
    const { requestIds } = this.cancellation.cancelSession(pageSessionId);
    this.queues.get(pageSessionId)?.stop(new DOMException("Cancelled", "AbortError"));
    await Promise.all(requestIds.map((requestId) => this.offscreenClient.cancel(requestId, pageSessionId)));
    await this.offscreenClient.cancel(null, pageSessionId);
    this.inflightRequests.clearSession(pageSessionId);
    const state = await this.tabStateStore.getState(pageSessionId);
    await this.tabStateStore.upsertState(pageSessionId, {
      stage: PIPELINE_STAGE.CANCELLED,
      cancelled: true,
      progress: {
        pending: 0,
        failed: state?.progress?.failed || 0,
        done: state?.progress?.done || 0,
        total: state?.progress?.total || 0
      }
    });
    await this.log({
      level: LOG_LEVEL.WARN,
      category: EVENT_CATEGORY.CANCELLATION,
      name: "hard_cancel",
      pageSessionId,
      tabId,
      data: {
        reason,
        requestIds
      }
    });
    await this.notifyState(tabId);
    return this.getUiState(tabId);
  }
  async switchView({ tabId, mode }) {
    const pageSessionId = await this.tabStateStore.getActiveSessionByTab(tabId);
    if (pageSessionId) {
      await this.tabStateStore.upsertState(pageSessionId, { viewMode: mode });
    }
    await this.sendTabMessageStrict(tabId, {
      type: MESSAGE.CONTENT_SWITCH_VIEW,
      mode
    });
    await this.log({
      category: EVENT_CATEGORY.UI_ACTION,
      name: "switch_view",
      pageSessionId,
      tabId,
      data: { mode }
    });
    await this.notifyState(tabId);
    return this.getUiState(tabId);
  }
  async clearAll({ tabId }) {
    const pageSessionId = await this.tabStateStore.getActiveSessionByTab(tabId);
    if (pageSessionId && this.running.has(pageSessionId)) {
      await this.hardCancel({ tabId, reason: "clear_all" });
    }
    try {
      await this.sendTabMessageStrict(tabId, { type: MESSAGE.CONTENT_CLEAR });
    } catch {
    }
    if (pageSessionId) {
      await this.tabStateStore.clearSession(pageSessionId);
      this.inflightRequests.clearSession(pageSessionId);
    }
    this.uiErrorsByTab.delete(String(tabId));
    await this.eventLogStore.clear();
    await this.log({
      category: EVENT_CATEGORY.UI_ACTION,
      name: "clear_all",
      tabId,
      data: { clearedSession: pageSessionId || null }
    });
    await this.notifyState(tabId);
    return this.getUiState(tabId);
  }
  async resumePending() {
    const all = await this.tabStateStore.getAllStates();
    for (const state of Object.values(all)) {
      if (!state || !state.tabId) {
        continue;
      }
      if (!this.isRunningStage(state.stage)) {
        continue;
      }
      if (this.running.has(state.pageSessionId)) {
        continue;
      }
      await this.log({
        level: LOG_LEVEL.WARN,
        category: EVENT_CATEGORY.PIPELINE_STAGE,
        name: "resume_orphan_session_detected",
        pageSessionId: state.pageSessionId,
        tabId: state.tabId,
        data: {
          previousStage: state.stage
        }
      });
      await this.tabStateStore.upsertState(state.pageSessionId, {
        stage: PIPELINE_STAGE.CANCELLED,
        cancelled: true,
        lastError: {
          message: "Service worker restarted. Session will be restarted."
        },
        progress: {
          ...state.progress || {},
          pending: 0
        }
      });
      const activeSession = await this.tabStateStore.getActiveSessionByTab(state.tabId);
      if (activeSession === state.pageSessionId) {
        await this.tabStateStore.setActiveSession(state.tabId, null);
      }
      await this.notifyState(state.tabId);
      try {
        await this.startForTab({
          tabId: state.tabId,
          url: state.url
        });
        await this.log({
          level: LOG_LEVEL.INFO,
          category: EVENT_CATEGORY.PIPELINE_STAGE,
          name: "resume_restarted_session",
          tabId: state.tabId,
          data: {
            previousSessionId: state.pageSessionId
          }
        });
      } catch (error) {
        await this.log({
          level: LOG_LEVEL.ERROR,
          category: EVENT_CATEGORY.ERROR,
          name: "resume_restart_failed",
          tabId: state.tabId,
          pageSessionId: state.pageSessionId,
          error: asErrorObject(error)
        });
      }
    }
  }
  async failSession({ pageSessionId, tabId, error }) {
    const state = await this.tabStateStore.getState(pageSessionId);
    await this.tabStateStore.upsertState(pageSessionId, {
      stage: PIPELINE_STAGE.FAILED,
      lastError: asErrorObject(error),
      progress: {
        ...state?.progress || {},
        errorCount: (state?.progress?.errorCount || 0) + 1
      }
    });
    await this.log({
      level: LOG_LEVEL.ERROR,
      category: EVENT_CATEGORY.ERROR,
      name: "pipeline_failed",
      pageSessionId,
      tabId,
      error: asErrorObject(error)
    });
    await this.notifyState(tabId);
  }
  async getUiState(tabId) {
    const pageSessionId = await this.tabStateStore.getActiveSessionByTab(tabId);
    const state = pageSessionId ? await this.tabStateStore.getState(pageSessionId) : null;
    if (!state) {
      const transientError = this.uiErrorsByTab.get(String(tabId)) || null;
      return {
        pageSessionId: null,
        stage: PIPELINE_STAGE.IDLE,
        progress: {
          done: 0,
          pending: 0,
          failed: 0,
          total: 0,
          errorCount: 0
        },
        viewMode: VIEW_MODE.ORIGINAL,
        hasTranslatedBlocks: false,
        isRunning: false,
        hasData: false,
        canCancel: false,
        canClear: false,
        lastError: transientError ? { message: transientError } : null
      };
    }
    const isRunning = this.running.has(pageSessionId) && !state.cancelled;
    const hasData = (state.progress?.total || 0) > 0 || !!state.hasTranslatedBlocks;
    return {
      ...state,
      isRunning,
      hasData,
      canCancel: isRunning,
      canClear: hasData
    };
  }
  async queryLogs(filters) {
    return this.eventLogStore.query(filters);
  }
  async exportLogs(filters) {
    return this.eventLogStore.exportJson(filters);
  }
  async appendEvent(event) {
    await this.log(event);
  }
  async log(event) {
    await this.eventLogStore.append({
      ts: event.ts || nowIso(),
      level: event.level || LOG_LEVEL.INFO,
      category: event.category,
      name: event.name,
      pageSessionId: event.pageSessionId || null,
      tabId: event.tabId ?? null,
      batchId: event.batchId || null,
      blockId: event.blockId || null,
      data: event.data || {},
      error: event.error || null
    });
    if (event.tabId !== null && event.tabId !== void 0) {
      await this.notifyState(event.tabId);
    } else {
      this.onStateChanged?.({ tabId: null });
    }
  }
  async updateStage(pageSessionId, tabId, stage) {
    await this.tabStateStore.upsertState(pageSessionId, { stage });
    await this.log({
      category: EVENT_CATEGORY.PIPELINE_STAGE,
      name: `stage_${stage}`,
      pageSessionId,
      tabId,
      data: { stage }
    });
    await this.notifyState(tabId);
  }
  async notifyState(tabId) {
    const state = await this.getUiState(tabId);
    this.onStateChanged?.({ tabId, state });
  }
  async waitQueueIdle(pageSessionId) {
    const queue = this.queues.get(pageSessionId);
    if (!queue) {
      return;
    }
    while (queue.size() > 0 || queue.active > 0) {
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
  }
  syncQueueConcurrency(pageSessionId, model) {
    const queue = this.queues.get(pageSessionId);
    const controller = this.controllerBySession.get(pageSessionId);
    if (!queue || !controller) {
      return;
    }
    const snapshot = controller.getSnapshot(model, { role: "translation" });
    const nextConcurrency = Math.max(
      1,
      Number(snapshot?.dynamicConcurrency || snapshot?.limits?.concurrency || queue.concurrency || 1)
    );
    if (queue.concurrency !== nextConcurrency) {
      queue.setConcurrency(nextConcurrency);
    }
  }
  isRunningStage(stage) {
    return [
      PIPELINE_STAGE.SCANNING,
      PIPELINE_STAGE.CONTEXT,
      PIPELINE_STAGE.BATCHING,
      PIPELINE_STAGE.TRANSLATING,
      PIPELINE_STAGE.APPLYING
    ].includes(stage);
  }
  async sendTabMessageStrict(tabId, payload) {
    const response = await chrome.tabs.sendMessage(tabId, payload);
    if (!response?.ok) {
      throw new Error(response?.error || "Tab message failed");
    }
    return response.result;
  }
  async throwIfCancelled(signal) {
    if (signal?.aborted) {
      throw new DOMException("Session cancelled", "AbortError");
    }
  }
  async handleMessage(message, sender) {
    switch (message?.type) {
      case MESSAGE.UI_START:
        return this.startForTab({ tabId: message.tabId, url: message.url });
      case MESSAGE.UI_CANCEL:
        return this.hardCancel({ tabId: message.tabId, reason: "ui_cancel" });
      case MESSAGE.UI_CLEAR:
        return this.clearAll({ tabId: message.tabId });
      case MESSAGE.UI_SWITCH_VIEW:
        return this.switchView({ tabId: message.tabId, mode: message.mode });
      case MESSAGE.UI_STATE:
        return this.getUiState(message.tabId);
      case MESSAGE.UI_LOAD_SETTINGS:
        return this.settingsStore.getSettings();
      case MESSAGE.UI_SAVE_SETTINGS:
        return this.saveSettings(message.settings);
      case MESSAGE.UI_SAVE_PROFILE:
        return this.saveProfile(message.name, message.profile);
      case MESSAGE.UI_LIST_MODELS:
        return this.listModels();
      case MESSAGE.UI_LIST_PROFILES:
        return this.settingsStore.listProfiles();
      case MESSAGE.LOG_QUERY:
        return this.queryLogs(message.filters || {});
      case MESSAGE.LOG_EXPORT:
        return this.exportLogs(message.filters || {});
      case MESSAGE.LOG_CLEAR:
        await this.eventLogStore.clear();
        return { cleared: true };
      case "event.emit":
        await this.appendEvent(message.event);
        return { logged: true };
      case MESSAGE.PIPELINE_RESUME:
        await this.resumePending();
        return { resumed: true };
      default:
        return null;
    }
  }
  async saveSettings(nextSettings) {
    await this.settingsStore.saveSettings(nextSettings);
    await this.log({
      category: EVENT_CATEGORY.UI_ACTION,
      name: "settings_saved",
      data: {
        accessMode: nextSettings.accessMode,
        promptCachingEnabled: nextSettings?.promptCaching?.enabled
      }
    });
    return nextSettings;
  }
  async saveProfile(name, profile) {
    const profiles = await this.settingsStore.saveProfile(name, profile);
    await this.log({
      category: EVENT_CATEGORY.UI_ACTION,
      name: "profile_saved",
      data: {
        name
      }
    });
    return profiles;
  }
  async listModels() {
    const settings = await this.settingsStore.getSettings();
    const useProxy = settings.accessMode === "PROXY";
    const baseUrl = useProxy ? settings.proxyBaseUrl : settings.byokBaseUrl;
    const token = useProxy ? settings.proxyToken : settings.byokApiKey;
    if (!baseUrl || !token) {
      return [];
    }
    const response = await this.offscreenClient.execute({
      requestId: `req_${stableHash(`models_${Date.now()}`)}`,
      pageSessionId: null,
      tabId: null,
      operation: "openai.models",
      payload: {
        baseUrl,
        useProxy
      },
      access: useProxy ? { mode: "PROXY", baseUrl, token } : { mode: "BYOK", baseUrl, apiKey: token }
    });
    return response.models || [];
  }
  async handleAlarm(alarm) {
    if (alarm.name === ALARM_RESUME_PIPELINE) {
      await this.runGc();
      await this.resumePending();
    }
  }
};
function buildContextChunks(blocks, maxTokensPerChunk) {
  const chunks = [];
  let current = [];
  let currentTokens = 0;
  for (const block of blocks) {
    const line = `[${block.blockId}] (${block.category}) ${block.text}`;
    const lineTokens = estimateTokens(line);
    if (current.length > 0 && currentTokens + lineTokens > maxTokensPerChunk) {
      chunks.push(current);
      current = [];
      currentTokens = 0;
    }
    current.push(block);
    currentTokens += lineTokens;
  }
  if (current.length > 0) {
    chunks.push(current);
  }
  if (chunks.length === 0) {
    return [[]];
  }
  return chunks;
}

// src/sw/worker.js
var settingsStore = new SettingsStore();
var tabStateStore = new TabStateStore();
var eventLogStore = new EventLogStore();
var offscreenClient = new OffscreenClient();
var ports = /* @__PURE__ */ new Set();
var orchestrator = new PipelineOrchestrator({
  settingsStore,
  tabStateStore,
  eventLogStore,
  offscreenClient,
  onStateChanged: ({ tabId, state }) => {
    for (const port of ports) {
      try {
        port.postMessage({
          type: "stream.state",
          tabId,
          state
        });
      } catch {
      }
    }
  }
});
bootstrap().catch((error) => {
  console.error("bootstrap_failed", error);
});
async function bootstrap() {
  await orchestrator.init();
  await orchestrator.resumePending();
}
chrome.runtime.onInstalled.addListener(async () => {
  await orchestrator.init();
});
chrome.runtime.onStartup.addListener(async () => {
  await orchestrator.init();
  await orchestrator.resumePending();
});
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== EVENT_STREAM_PORT) {
    return;
  }
  ports.add(port);
  port.onMessage.addListener(async (message) => {
    if (message?.type === "stream.subscribe" && Number.isInteger(message.tabId)) {
      const state = await orchestrator.getUiState(message.tabId);
      port.postMessage({ type: "stream.state", tabId: message.tabId, state });
    }
  });
  port.onDisconnect.addListener(() => {
    ports.delete(port);
  });
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === MESSAGE.OFFSCREEN_EXECUTE || message?.type === MESSAGE.OFFSCREEN_CANCEL) {
    return false;
  }
  Promise.resolve(orchestrator.handleMessage(message, sender)).then((result) => sendResponse({ ok: true, result })).catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
  return true;
});
chrome.alarms.onAlarm.addListener((alarm) => {
  orchestrator.handleAlarm(alarm).catch((error) => {
    orchestrator.appendEvent({
      level: "error",
      category: "error",
      name: "alarm_handler_failed",
      error: {
        message: error?.message || String(error),
        stack: error?.stack
      }
    });
  });
});
//# sourceMappingURL=worker.js.map

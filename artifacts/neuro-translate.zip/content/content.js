// src/shared/constants.js
var MESSAGE = Object.freeze({
  UI_START: "ui.start",
  UI_CANCEL: "ui.cancel",
  UI_CLEAR: "ui.clear",
  UI_SWITCH_VIEW: "ui.switch_view",
  UI_STATE: "ui.state",
  UI_PING: "ui.ping",
  UI_LOAD_SETTINGS: "ui.load_settings",
  UI_SAVE_SETTINGS: "ui.save_settings",
  UI_SAVE_PROFILE: "ui.save_profile",
  UI_LIST_MODELS: "ui.list_models",
  UI_LIST_PROFILES: "ui.list_profiles",
  LOG_QUERY: "log.query",
  LOG_EXPORT: "log.export",
  LOG_CLEAR: "log.clear",
  CONTENT_SCAN: "content.scan",
  CONTENT_APPLY_BATCH: "content.apply_batch",
  CONTENT_SWITCH_VIEW: "content.switch_view",
  CONTENT_CLEAR: "content.clear",
  OFFSCREEN_EXECUTE: "offscreen.execute",
  OFFSCREEN_CANCEL: "offscreen.cancel",
  PIPELINE_RESUME: "pipeline.resume"
});
var VIEW_MODE = Object.freeze({
  TRANSLATION: "translation",
  ORIGINAL: "original",
  DIFF: "diff"
});
var PIPELINE_STAGE = Object.freeze({
  IDLE: "idle",
  SCANNING: "scanning",
  CONTEXT: "context",
  BATCHING: "batching",
  TRANSLATING: "translating",
  APPLYING: "applying",
  DONE: "done",
  CANCELLED: "cancelled",
  FAILED: "failed"
});
var LOG_LEVEL = Object.freeze({
  DEBUG: "debug",
  INFO: "info",
  WARN: "warn",
  ERROR: "error"
});
var EVENT_CATEGORY = Object.freeze({
  UI_ACTION: "ui.action",
  PIPELINE_STAGE: "pipeline.stage",
  DOM_SCAN: "dom.scan",
  DOM_CLASSIFY: "dom.classify",
  DOM_APPLY: "dom.apply",
  CONTEXT_GENERATE: "context.generate",
  CONTEXT_COMPACT: "context.compact",
  BATCH_CREATE: "batch.create",
  BATCH_TRANSLATE: "batch.translate",
  OPENAI_REQUEST: "openai.request",
  OPENAI_RESPONSE: "openai.response",
  OPENAI_RATE_LIMIT: "openai.rate_limit",
  CANCELLATION: "cancellation",
  STORAGE_GC: "storage.gc",
  ERROR: "error"
});
var STORAGE_KEYS = Object.freeze({
  SETTINGS: "settings",
  PROFILES: "profiles",
  TAB_STATES: "tabStates",
  ACTIVE_SESSION_BY_TAB: "activeSessionByTab"
});
var DEFAULT_SETTINGS = Object.freeze({
  activeProfileName: "default",
  selectedViewMode: VIEW_MODE.ORIGINAL,
  accessMode: "BYOK",
  byokApiKey: "",
  byokBaseUrl: "https://api.openai.com/v1",
  proxyToken: "",
  proxyBaseUrl: "",
  promptCaching: {
    enabled: true,
    scope: "profile"
  },
  globalContext: {
    targetTokens: 15e3,
    maxOutputTokens: 4096,
    model: "gpt-4.1-mini"
  },
  batching: {
    blockLimits: {
      minChars: 1,
      maxChars: 2800
    },
    batchTokenTarget: 1200,
    maxBlocksPerBatch: 24
  },
  batchWindow: {
    prevBatchesCount: 3,
    compactAfter: 8,
    compactPolicy: "rolling"
  },
  compaction: {
    model: "gpt-4.1-mini",
    prompt: "Compact translated history preserving terms and entities.",
    thresholds: {
      tokenTarget: 450,
      startAfterBatch: 8
    }
  },
  storagePolicy: {
    whatToKeep: "full",
    maxBytes: 3e6,
    maxRecords: 8e3,
    maxAgeMs: 1e3 * 60 * 60 * 24 * 7,
    gcPolicy: "lru"
  },
  models: {
    selected: ["gpt-4.1-mini", "gpt-4.1-nano"],
    sortablePricing: true
  },
  modelPriority: {
    context: ["gpt-4.1-mini", "gpt-4.1-nano"],
    translation: ["gpt-4.1-mini", "gpt-4.1-nano"]
  },
  rateLimits: {
    safetyBufferTokens: 500,
    perModel: {
      "gpt-4.1-mini": { tpm: 18e4, rpm: 500, concurrency: 3 },
      "gpt-4.1-nano": { tpm: 3e5, rpm: 600, concurrency: 4 }
    }
  },
  mockMode: {
    enabled: false,
    artificialDelayMs: 120,
    forceError: false
  }
});
var DEFAULT_PROFILE_TEMPLATE = Object.freeze({
  promptCaching: { ...DEFAULT_SETTINGS.promptCaching },
  globalContext: { ...DEFAULT_SETTINGS.globalContext },
  batching: { ...DEFAULT_SETTINGS.batching },
  batchWindow: { ...DEFAULT_SETTINGS.batchWindow },
  compaction: { ...DEFAULT_SETTINGS.compaction },
  storagePolicy: { ...DEFAULT_SETTINGS.storagePolicy },
  models: { ...DEFAULT_SETTINGS.models },
  modelPriority: { ...DEFAULT_SETTINGS.modelPriority },
  rateLimits: { ...DEFAULT_SETTINGS.rateLimits }
});
var MODEL_PRICE_CATALOG = Object.freeze({
  "gpt-4.1": { input: 10, output: 30, cachedInput: 2.5 },
  "gpt-4.1-mini": { input: 0.8, output: 3.2, cachedInput: 0.2 },
  "gpt-4.1-nano": { input: 0.2, output: 0.8, cachedInput: 0.05 },
  "gpt-5": { input: 15, output: 45, cachedInput: 3.75 },
  "gpt-5-mini": { input: 1.2, output: 4.8, cachedInput: 0.3 },
  "gpt-5-nano": { input: 0.4, output: 1.6, cachedInput: 0.1 }
});

// src/content/dom-classifier.js
var CATEGORY_BY_TAG = Object.freeze({
  H1: "heading",
  H2: "heading",
  H3: "heading",
  H4: "heading",
  H5: "heading",
  H6: "heading",
  P: "paragraph",
  LI: "list_item",
  BUTTON: "control",
  A: "link",
  LABEL: "label",
  SPAN: "inline"
});
function classifyBlock(block) {
  const byTag = CATEGORY_BY_TAG[block.parentTag];
  if (byTag) {
    return byTag;
  }
  if (block.text.length < 30) {
    return "short_text";
  }
  if (block.text.length > 240) {
    return "long_text";
  }
  return "generic";
}
function classifyBlocks(blocks) {
  return blocks.map((block) => ({
    ...block,
    category: classifyBlock(block)
  }));
}

// src/shared/utils.js
function stableHash(input) {
  const text = typeof input === "string" ? input : JSON.stringify(input);
  let hash = 2166136261;
  for (let i = 0; i < text.length; i += 1) {
    hash ^= text.charCodeAt(i);
    hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}

// src/content/dom-indexer.js
var SKIP_TAGS = /* @__PURE__ */ new Set(["SCRIPT", "STYLE", "NOSCRIPT", "CODE", "PRE", "TEXTAREA", "INPUT"]);
var ANCHOR_ATTR = "data-nt-anchor-id";
var anchorCounter = 0;
function isVisibleElement(element) {
  if (!element || !(element instanceof Element)) {
    return false;
  }
  const style = window.getComputedStyle(element);
  if (style.display === "none" || style.visibility === "hidden") {
    return false;
  }
  if (element.closest("[aria-hidden='true']")) {
    return false;
  }
  return true;
}
function shouldSkipNode(textNode) {
  const parent = textNode.parentElement;
  if (!parent) {
    return true;
  }
  if (SKIP_TAGS.has(parent.tagName)) {
    return true;
  }
  if (!isVisibleElement(parent)) {
    return true;
  }
  const value = textNode.nodeValue || "";
  if (!value.trim()) {
    return true;
  }
  return false;
}
function createNodePath(textNode) {
  const path = [];
  let cursor = textNode;
  while (cursor && cursor !== document.body) {
    const parent = cursor.parentNode;
    if (!parent) {
      break;
    }
    const index = Array.prototype.indexOf.call(parent.childNodes, cursor);
    path.push(index);
    cursor = parent;
  }
  path.push(0);
  return path.reverse();
}
function resolveNodePath(path) {
  if (!Array.isArray(path) || path.length === 0) {
    return null;
  }
  let cursor = document.body;
  for (let i = 1; i < path.length; i += 1) {
    const idx = path[i];
    cursor = cursor?.childNodes?.[idx] || null;
    if (!cursor) {
      return null;
    }
  }
  return cursor.nodeType === Node.TEXT_NODE ? cursor : null;
}
function resolveAnchor(anchor) {
  if (!anchor || typeof anchor !== "object") {
    return null;
  }
  const byPath = resolveNodePath(anchor.path);
  if (byPath && matchesTextHash(byPath, anchor.textHash)) {
    return byPath;
  }
  if (anchor.parentAnchorId) {
    const escapedId = escapeAttributeValue(anchor.parentAnchorId);
    const parent = document.querySelector(`[${ANCHOR_ATTR}="${escapedId}"]`);
    if (parent) {
      const byHash = findTextNodeByHash(parent, anchor.textHash);
      if (byHash) {
        return byHash;
      }
      return findFirstUsefulTextNode(parent);
    }
  }
  return byPath;
}
function scanTextBlocks() {
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  const blocks = [];
  let order = 0;
  while (walker.nextNode()) {
    const textNode = walker.currentNode;
    if (shouldSkipNode(textNode)) {
      continue;
    }
    const path = createNodePath(textNode);
    const text = textNode.nodeValue.trim();
    const parentAnchorId = getOrCreateParentAnchorId(textNode.parentElement);
    const textHash = stableHash(text);
    const blockId = `blk_${stableHash(`${location.href}|${parentAnchorId}|${path.join(".")}|${textHash}`)}`;
    blocks.push({
      blockId,
      text,
      order,
      anchor: {
        path,
        parentAnchorId,
        textHash
      },
      parentTag: textNode.parentElement?.tagName || "DIV"
    });
    order += 1;
  }
  return blocks;
}
function getOrCreateParentAnchorId(element) {
  if (!element || !(element instanceof Element)) {
    return "";
  }
  const existing = element.getAttribute(ANCHOR_ATTR);
  if (existing) {
    return existing;
  }
  const created = `nta_${++anchorCounter}_${stableHash(element.tagName + (element.className || "")).slice(0, 6)}`;
  element.setAttribute(ANCHOR_ATTR, created);
  return created;
}
function matchesTextHash(node, expectedHash) {
  if (!expectedHash || !node) {
    return true;
  }
  const text = String(node.nodeValue || "").trim();
  if (!text) {
    return false;
  }
  return stableHash(text) === expectedHash;
}
function findTextNodeByHash(parent, expectedHash) {
  if (!expectedHash) {
    return null;
  }
  const walker = document.createTreeWalker(parent, NodeFilter.SHOW_TEXT);
  while (walker.nextNode()) {
    const node = walker.currentNode;
    const text = String(node.nodeValue || "").trim();
    if (!text) {
      continue;
    }
    if (stableHash(text) === expectedHash) {
      return node;
    }
  }
  return null;
}
function findFirstUsefulTextNode(parent) {
  const walker = document.createTreeWalker(parent, NodeFilter.SHOW_TEXT);
  while (walker.nextNode()) {
    const node = walker.currentNode;
    if (String(node.nodeValue || "").trim()) {
      return node;
    }
  }
  return null;
}
function escapeAttributeValue(value) {
  const input = String(value ?? "");
  if (globalThis.CSS?.escape) {
    return globalThis.CSS.escape(input);
  }
  return input.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}

// src/content/dom-applier.js
var DomApplier = class {
  constructor() {
    this.registry = /* @__PURE__ */ new Map();
    this.viewMode = VIEW_MODE.ORIGINAL;
  }
  prime(blocks) {
    for (const block of blocks) {
      const node = resolveAnchor(block.anchor);
      if (!node) {
        continue;
      }
      if (!this.registry.has(block.blockId)) {
        this.registry.set(block.blockId, {
          blockId: block.blockId,
          anchor: block.anchor,
          node,
          originalText: node.nodeValue,
          translatedText: null
        });
      }
    }
  }
  applyBatch(batch) {
    let applied = 0;
    for (const row of batch.translations || []) {
      const entry = this.registry.get(row.blockId);
      if (!entry) {
        continue;
      }
      entry.translatedText = row.translatedText;
      this.applyViewForEntry(entry, this.viewMode, row.warnings || []);
      applied += 1;
    }
    return applied;
  }
  switchView(mode) {
    this.viewMode = mode;
    for (const entry of this.registry.values()) {
      this.applyViewForEntry(entry, mode, []);
    }
  }
  clearAll() {
    for (const entry of this.registry.values()) {
      if (entry.node?.isConnected) {
        entry.node.nodeValue = entry.originalText;
      }
      const element = entry.node?.parentElement;
      if (element) {
        element.classList.remove("neuro-translate-diff");
      }
    }
    this.registry.clear();
    this.viewMode = VIEW_MODE.ORIGINAL;
  }
  hasTranslations() {
    for (const entry of this.registry.values()) {
      if (entry.translatedText) {
        return true;
      }
    }
    return false;
  }
  stats() {
    let translated = 0;
    for (const entry of this.registry.values()) {
      if (entry.translatedText) {
        translated += 1;
      }
    }
    return {
      total: this.registry.size,
      translated
    };
  }
  ensureNode(entry) {
    if (entry.node?.isConnected) {
      return entry.node;
    }
    const node = resolveAnchor(entry.anchor);
    if (!node) {
      return null;
    }
    entry.node = node;
    return node;
  }
  applyViewForEntry(entry, mode) {
    const node = this.ensureNode(entry);
    if (!node) {
      return;
    }
    const original = entry.originalText;
    const translated = entry.translatedText;
    if (!translated || mode === VIEW_MODE.ORIGINAL) {
      node.nodeValue = original;
      node.parentElement?.classList.remove("neuro-translate-diff");
      return;
    }
    if (mode === VIEW_MODE.TRANSLATION) {
      node.nodeValue = translated;
      node.parentElement?.classList.remove("neuro-translate-diff");
      return;
    }
    node.nodeValue = `${translated}  |  ${original}`;
    node.parentElement?.classList.add("neuro-translate-diff");
  }
};

// src/content/content.js
var domApplier = new DomApplier();
var latestBlocks = [];
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  Promise.resolve().then(async () => {
    switch (message?.type) {
      case MESSAGE.UI_PING:
        return {
          ready: true,
          href: location.href
        };
      case MESSAGE.CONTENT_SCAN:
        return handleScan(message);
      case MESSAGE.CONTENT_APPLY_BATCH:
        return handleApplyBatch(message);
      case MESSAGE.CONTENT_SWITCH_VIEW:
        return handleSwitchView(message);
      case MESSAGE.CONTENT_CLEAR:
        return handleClear();
      default:
        return null;
    }
  }).then((result) => sendResponse({ ok: true, result })).catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
  return true;
});
function handleScan(message) {
  const rawBlocks = scanTextBlocks();
  const blocks = classifyBlocks(rawBlocks).sort((a, b) => a.order - b.order);
  latestBlocks = blocks;
  domApplier.prime(blocks);
  chrome.runtime.sendMessage({
    type: "event.emit",
    event: {
      level: "info",
      category: "dom.scan",
      name: "content_scanned",
      pageSessionId: message.pageSessionId,
      tabId: message.tabId,
      data: {
        count: blocks.length
      }
    }
  });
  const categoryCounts = {};
  for (const block of blocks) {
    categoryCounts[block.category] = (categoryCounts[block.category] || 0) + 1;
  }
  chrome.runtime.sendMessage({
    type: "event.emit",
    event: {
      level: "info",
      category: "dom.classify",
      name: "content_classified",
      pageSessionId: message.pageSessionId,
      tabId: message.tabId,
      data: {
        count: blocks.length,
        categoryCounts
      }
    }
  });
  return {
    blocks
  };
}
function handleApplyBatch(message) {
  const applied = domApplier.applyBatch(message.payload);
  const stats = domApplier.stats();
  chrome.runtime.sendMessage({
    type: "event.emit",
    event: {
      level: "info",
      category: "dom.apply",
      name: "batch_applied_to_dom",
      pageSessionId: message.pageSessionId,
      tabId: message.tabId,
      batchId: message.payload.batchId,
      data: {
        applied,
        translated: stats.translated,
        total: stats.total
      }
    }
  });
  return {
    applied,
    stats
  };
}
function handleSwitchView(message) {
  const mode = Object.values(VIEW_MODE).includes(message.mode) ? message.mode : VIEW_MODE.ORIGINAL;
  domApplier.switchView(mode);
  return { mode };
}
function handleClear() {
  domApplier.clearAll();
  latestBlocks = [];
  return { cleared: true };
}
window.addEventListener("beforeunload", () => {
  domApplier.clearAll();
});
//# sourceMappingURL=content.js.map

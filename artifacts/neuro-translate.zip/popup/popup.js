// src/shared/constants.js
var MESSAGE = Object.freeze({
  UI_START: "ui.start",
  UI_CANCEL: "ui.cancel",
  UI_CLEAR: "ui.clear",
  UI_SWITCH_VIEW: "ui.switch_view",
  UI_STATE: "ui.state",
  UI_PING: "ui.ping",
  UI_LOAD_SETTINGS: "ui.load_settings",
  UI_SAVE_SETTINGS: "ui.save_settings",
  UI_SAVE_PROFILE: "ui.save_profile",
  UI_LIST_MODELS: "ui.list_models",
  UI_LIST_PROFILES: "ui.list_profiles",
  LOG_QUERY: "log.query",
  LOG_EXPORT: "log.export",
  LOG_CLEAR: "log.clear",
  CONTENT_SCAN: "content.scan",
  CONTENT_APPLY_BATCH: "content.apply_batch",
  CONTENT_SWITCH_VIEW: "content.switch_view",
  CONTENT_CLEAR: "content.clear",
  OFFSCREEN_EXECUTE: "offscreen.execute",
  OFFSCREEN_CANCEL: "offscreen.cancel",
  PIPELINE_RESUME: "pipeline.resume"
});
var VIEW_MODE = Object.freeze({
  TRANSLATION: "translation",
  ORIGINAL: "original",
  DIFF: "diff"
});
var PIPELINE_STAGE = Object.freeze({
  IDLE: "idle",
  SCANNING: "scanning",
  CONTEXT: "context",
  BATCHING: "batching",
  TRANSLATING: "translating",
  APPLYING: "applying",
  DONE: "done",
  CANCELLED: "cancelled",
  FAILED: "failed"
});
var LOG_LEVEL = Object.freeze({
  DEBUG: "debug",
  INFO: "info",
  WARN: "warn",
  ERROR: "error"
});
var EVENT_CATEGORY = Object.freeze({
  UI_ACTION: "ui.action",
  PIPELINE_STAGE: "pipeline.stage",
  DOM_SCAN: "dom.scan",
  DOM_CLASSIFY: "dom.classify",
  DOM_APPLY: "dom.apply",
  CONTEXT_GENERATE: "context.generate",
  CONTEXT_COMPACT: "context.compact",
  BATCH_CREATE: "batch.create",
  BATCH_TRANSLATE: "batch.translate",
  OPENAI_REQUEST: "openai.request",
  OPENAI_RESPONSE: "openai.response",
  OPENAI_RATE_LIMIT: "openai.rate_limit",
  CANCELLATION: "cancellation",
  STORAGE_GC: "storage.gc",
  ERROR: "error"
});
var STORAGE_KEYS = Object.freeze({
  SETTINGS: "settings",
  PROFILES: "profiles",
  TAB_STATES: "tabStates",
  ACTIVE_SESSION_BY_TAB: "activeSessionByTab"
});
var DEFAULT_SETTINGS = Object.freeze({
  activeProfileName: "default",
  selectedViewMode: VIEW_MODE.ORIGINAL,
  accessMode: "BYOK",
  byokApiKey: "",
  byokBaseUrl: "https://api.openai.com/v1",
  proxyToken: "",
  proxyBaseUrl: "",
  promptCaching: {
    enabled: true,
    scope: "profile"
  },
  globalContext: {
    targetTokens: 15e3,
    maxOutputTokens: 4096,
    model: "gpt-4.1-mini"
  },
  batching: {
    blockLimits: {
      minChars: 1,
      maxChars: 2800
    },
    batchTokenTarget: 1200,
    maxBlocksPerBatch: 24
  },
  batchWindow: {
    prevBatchesCount: 3,
    compactAfter: 8,
    compactPolicy: "rolling"
  },
  compaction: {
    model: "gpt-4.1-mini",
    prompt: "Compact translated history preserving terms and entities.",
    thresholds: {
      tokenTarget: 450,
      startAfterBatch: 8
    }
  },
  storagePolicy: {
    whatToKeep: "full",
    maxBytes: 3e6,
    maxRecords: 8e3,
    maxAgeMs: 1e3 * 60 * 60 * 24 * 7,
    gcPolicy: "lru"
  },
  models: {
    selected: ["gpt-4.1-mini", "gpt-4.1-nano"],
    sortablePricing: true
  },
  modelPriority: {
    context: ["gpt-4.1-mini", "gpt-4.1-nano"],
    translation: ["gpt-4.1-mini", "gpt-4.1-nano"]
  },
  rateLimits: {
    safetyBufferTokens: 500,
    perModel: {
      "gpt-4.1-mini": { tpm: 18e4, rpm: 500, concurrency: 3 },
      "gpt-4.1-nano": { tpm: 3e5, rpm: 600, concurrency: 4 }
    }
  },
  mockMode: {
    enabled: false,
    artificialDelayMs: 120,
    forceError: false
  }
});
var DEFAULT_PROFILE_TEMPLATE = Object.freeze({
  promptCaching: { ...DEFAULT_SETTINGS.promptCaching },
  globalContext: { ...DEFAULT_SETTINGS.globalContext },
  batching: { ...DEFAULT_SETTINGS.batching },
  batchWindow: { ...DEFAULT_SETTINGS.batchWindow },
  compaction: { ...DEFAULT_SETTINGS.compaction },
  storagePolicy: { ...DEFAULT_SETTINGS.storagePolicy },
  models: { ...DEFAULT_SETTINGS.models },
  modelPriority: { ...DEFAULT_SETTINGS.modelPriority },
  rateLimits: { ...DEFAULT_SETTINGS.rateLimits }
});
var MODEL_PRICE_CATALOG = Object.freeze({
  "gpt-4.1": { input: 10, output: 30, cachedInput: 2.5 },
  "gpt-4.1-mini": { input: 0.8, output: 3.2, cachedInput: 0.2 },
  "gpt-4.1-nano": { input: 0.2, output: 0.8, cachedInput: 0.05 },
  "gpt-5": { input: 15, output: 45, cachedInput: 3.75 },
  "gpt-5-mini": { input: 1.2, output: 4.8, cachedInput: 0.3 },
  "gpt-5-nano": { input: 0.4, output: 1.6, cachedInput: 0.1 }
});
var EVENT_STREAM_PORT = "event_stream_port";

// src/shared/profile-field-meta.js
var PROFILE_FIELD_META = Object.freeze({
  "promptCaching.enabled": { type: "boolean", enum: [true, false] },
  "promptCaching.scope": { type: "string", enum: ["profile", "session"] },
  "globalContext.targetTokens": { type: "number" },
  "globalContext.maxOutputTokens": { type: "number" },
  "globalContext.model": { type: "string" },
  "batching.blockLimits.minChars": { type: "number" },
  "batching.blockLimits.maxChars": { type: "number" },
  "batching.batchTokenTarget": { type: "number" },
  "batching.maxBlocksPerBatch": { type: "number" },
  "batchWindow.prevBatchesCount": { type: "number" },
  "batchWindow.compactAfter": { type: "number" },
  "batchWindow.compactPolicy": { type: "string", enum: ["rolling", "fixed"] },
  "compaction.model": { type: "string" },
  "compaction.prompt": { type: "string" },
  "compaction.thresholds.tokenTarget": { type: "number" },
  "compaction.thresholds.startAfterBatch": { type: "number" },
  "storagePolicy.whatToKeep": { type: "string", enum: ["full", "minimal"] },
  "storagePolicy.maxBytes": { type: "number" },
  "storagePolicy.maxRecords": { type: "number" },
  "storagePolicy.maxAgeMs": { type: "number" },
  "storagePolicy.gcPolicy": { type: "string", enum: ["lru", "ttl"] },
  "modelPriority.context": { type: "array" },
  "modelPriority.translation": { type: "array" }
});

// src/shared/runtime-api.js
async function callRuntime(type, payload = {}) {
  const response = await chrome.runtime.sendMessage({ type, ...payload });
  if (!response?.ok) {
    throw new Error(response?.error || `Runtime message failed: ${type}`);
  }
  return response.result;
}
function connectPort(name) {
  return chrome.runtime.connect({ name });
}

// src/shared/utils.js
function deepClone(value) {
  return structuredClone(value);
}
function getValueByPath(obj, path) {
  return path.split(".").reduce((acc, part) => {
    if (acc === null || acc === void 0) {
      return void 0;
    }
    return acc[part];
  }, obj);
}
function setValueByPath(obj, path, value) {
  const parts = path.split(".");
  const last = parts.pop();
  if (!last) {
    return obj;
  }
  let cursor = obj;
  for (const part of parts) {
    if (typeof cursor[part] !== "object" || cursor[part] === null) {
      cursor[part] = {};
    }
    cursor = cursor[part];
  }
  cursor[last] = value;
  return obj;
}
function toSortedJson(value) {
  return JSON.stringify(sortObject(value), null, 2);
}
function sortObject(value) {
  if (Array.isArray(value)) {
    return value.map(sortObject);
  }
  if (value && typeof value === "object") {
    return Object.keys(value).sort().reduce((acc, key) => {
      acc[key] = sortObject(value[key]);
      return acc;
    }, {});
  }
  return value;
}

// src/popup/popup.js
var app = document.getElementById("app");
var EMPTY_PROGRESS = Object.freeze({
  done: 0,
  pending: 0,
  failed: 0,
  total: 0,
  errorCount: 0
});
var EMPTY_UI_STATE = Object.freeze({
  pageSessionId: null,
  stage: PIPELINE_STAGE.IDLE,
  progress: EMPTY_PROGRESS,
  viewMode: VIEW_MODE.ORIGINAL,
  hasTranslatedBlocks: false,
  isRunning: false,
  hasData: false,
  canCancel: false,
  canClear: false,
  lastError: null
});
var CUSTOM_PROFILE_OPTION = "__custom__";
var state = {
  tabId: null,
  tabUrl: "",
  uiState: deepClone(EMPTY_UI_STATE),
  settings: null,
  profiles: {},
  modelsCatalog: [],
  panel: "status",
  profileNameDraft: "default",
  fieldEditor: {
    path: ""
  },
  eventFilters: {
    category: "",
    onlyErrors: false
  },
  streamPort: null,
  refreshTimer: null
};
renderShell();
wireTabs();
wireHeaderActions();
await init();
async function init() {
  try {
    await resolveActiveTab();
    await loadSettings();
    await refreshState();
    renderEventsPanel();
    await refreshLogs();
    connectStateStream();
    state.refreshTimer = setInterval(() => {
      refreshLogs().catch(() => {
      });
    }, 1800);
    window.addEventListener("beforeunload", () => {
      if (state.refreshTimer) {
        clearInterval(state.refreshTimer);
      }
      try {
        state.streamPort?.disconnect();
      } catch {
      }
    });
  } catch (error) {
    setTransientError(error?.message || "Popup init failed");
    renderStatusPanel();
  }
}
async function resolveActiveTab() {
  const params = new URLSearchParams(location.search);
  const forcedTabId = Number(params.get("tabId"));
  const forcedUrl = params.get("url");
  if (Number.isInteger(forcedTabId) && forcedTabId > 0) {
    state.tabId = forcedTabId;
    state.tabUrl = forcedUrl || "";
    return;
  }
  const tabs = await chrome.tabs.query({ currentWindow: true });
  const activeHttp = tabs.find((tab) => tab.active && /^https?:/i.test(tab.url || ""));
  const fallbackHttp = tabs.find((tab) => /^https?:/i.test(tab.url || ""));
  const fallbackAny = tabs.find((tab) => Number.isInteger(tab.id));
  const target = activeHttp || fallbackHttp || fallbackAny || null;
  state.tabId = target?.id || null;
  state.tabUrl = target?.url || "";
}
function renderShell() {
  app.innerHTML = `
    <header class="popup-header">
      <div>
        <h1 class="popup-title">Neuro Translate</h1>
        <p class="popup-subtitle">\u0423\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u043E\u043C \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B</p>
      </div>
      <button class="icon-btn" id="btn-open-debug" title="\u041E\u0442\u043A\u0440\u044B\u0442\u044C debug">\u2699</button>
    </header>
    <nav class="top-tabs" role="tablist">
      <button class="tab-btn" data-tab="status" aria-selected="true" title="\u0421\u0442\u0430\u0442\u0443\u0441">\u0421\u0442\u0430\u0442\u0443\u0441</button>
      <button class="tab-btn" data-tab="settings" aria-selected="false" title="\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438">\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438</button>
      <button class="tab-btn" data-tab="events" aria-selected="false" title="\u0421\u043E\u0431\u044B\u0442\u0438\u044F">\u0421\u043E\u0431\u044B\u0442\u0438\u044F</button>
    </nav>
    <section class="panel active" data-panel="status"></section>
    <section class="panel" data-panel="settings"></section>
    <section class="panel" data-panel="events"></section>
  `;
}
function wireTabs() {
  app.querySelectorAll(".tab-btn").forEach((button) => {
    button.addEventListener("click", () => {
      switchPanel(button.dataset.tab);
    });
  });
}
function wireHeaderActions() {
  app.querySelector("#btn-open-debug")?.addEventListener("click", openDebugPage);
}
function switchPanel(panelName) {
  state.panel = panelName;
  app.querySelectorAll(".tab-btn").forEach((button) => {
    const selected = button.dataset.tab === panelName;
    button.setAttribute("aria-selected", String(selected));
  });
  app.querySelectorAll(".panel").forEach((panel) => {
    panel.classList.toggle("active", panel.dataset.panel === panelName);
  });
  if (panelName === "events") {
    refreshLogs().catch(() => {
    });
  }
}
function connectStateStream() {
  try {
    state.streamPort = connectPort(EVENT_STREAM_PORT);
  } catch {
    return;
  }
  state.streamPort.postMessage({
    type: "stream.subscribe",
    tabId: state.tabId
  });
  state.streamPort.onMessage.addListener((message) => {
    if (message?.type !== "stream.state") {
      return;
    }
    if (message.tabId !== state.tabId) {
      return;
    }
    state.uiState = mergeUiState(message.state);
    renderStatusPanel();
  });
  state.streamPort.onDisconnect.addListener(() => {
    state.streamPort = null;
    setTimeout(() => {
      if (!state.streamPort) {
        connectStateStream();
      }
    }, 600);
  });
}
function mergeUiState(nextState) {
  const merged = {
    ...deepClone(EMPTY_UI_STATE),
    ...nextState || {}
  };
  merged.progress = {
    ...EMPTY_PROGRESS,
    ...nextState?.progress || {}
  };
  return merged;
}
async function loadSettings() {
  state.settings = await callRuntime(MESSAGE.UI_LOAD_SETTINGS);
  state.profiles = await callRuntime(MESSAGE.UI_LIST_PROFILES);
  const activeName = state.settings.activeProfileName || "default";
  const profileExists = state.profiles[activeName];
  if (!profileExists) {
    state.settings.activeProfileName = "default";
  }
  if (!state.settings.profileDraft) {
    const selectedProfile = state.profiles[state.settings.activeProfileName] || deepClone(DEFAULT_PROFILE_TEMPLATE);
    state.settings.profileDraft = deepClone(selectedProfile);
  }
  state.profileNameDraft = state.settings.activeProfileName || "default";
  renderSettingsPanel();
}
async function refreshState() {
  const uiState = await callRuntime(MESSAGE.UI_STATE, { tabId: state.tabId });
  state.uiState = mergeUiState(uiState);
  renderStatusPanel();
}
function renderStatusPanel() {
  const panel = app.querySelector('[data-panel="status"]');
  if (!panel) {
    return;
  }
  const ui = mergeUiState(state.uiState);
  const progress = ui.progress;
  const total = Number(progress.total) || 0;
  const done = Number(progress.done) || 0;
  const pending = Number(progress.pending) || 0;
  const failed = Number(progress.failed) || 0;
  const errorCount = Number(progress.errorCount) || 0;
  const completed = done + failed;
  const percent = total > 0 ? Math.round(completed / total * 100) : 0;
  const hasTranslated = Boolean(ui.hasTranslatedBlocks);
  const isRunning = Boolean(ui.isRunning);
  const canClear = Boolean(ui.canClear);
  const canStart = canRunOnCurrentTab() && !isRunning;
  const stage = ui.stage || PIPELINE_STAGE.IDLE;
  const viewMode = ui.viewMode || VIEW_MODE.ORIGINAL;
  const hintIfNoTab = canRunOnCurrentTab() ? "" : "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0430\u043A\u0442\u0438\u0432\u043D\u0443\u044E http/https \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443";
  const lastError = ui.lastError?.message || hintIfNoTab;
  panel.innerHTML = `
    <div class="status-grid">
      <div class="progress-shell">
        <progress max="100" value="${percent}"></progress>
        <div class="summary-line">
          <span title="done / pending / failed">${done} / ${pending} / ${failed}</span>
          <span class="error-pill" id="error-pill" title="\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043E\u0448\u0438\u0431\u043A\u0438">err: ${errorCount}</span>
        </div>
        <div class="summary-line">
          <span title="\u0421\u0442\u0430\u0434\u0438\u044F">${escapeHtml(stage)}</span>
          <span>${percent}%</span>
        </div>
        ${lastError ? `<div class="summary-line"><span title="\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u044F\u044F \u043E\u0448\u0438\u0431\u043A\u0430">${escapeHtml(lastError)}</span></div>` : ""}
      </div>

      <div class="action-row">
        <button class="icon-btn" id="btn-start" title="\u0417\u0430\u043F\u0443\u0441\u043A \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430" ${canStart ? "" : "disabled"}>\u25B6</button>
        <button class="icon-btn" id="btn-cancel" title="\u0416\u0451\u0441\u0442\u043A\u0430\u044F \u043E\u0442\u043C\u0435\u043D\u0430" ${isRunning ? "" : "disabled"}>\u25A0</button>
        <button class="icon-btn" id="btn-clear" title="\u0421\u0442\u0435\u0440\u0435\u0442\u044C \u0432\u0441\u0451" ${canClear ? "" : "disabled"}>\u232B</button>
      </div>

      <div class="view-row">
        <button class="icon-btn ${viewMode === VIEW_MODE.TRANSLATION ? "active" : ""}" id="btn-view-translation" title="\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043F\u0435\u0440\u0435\u0432\u043E\u0434" ${hasTranslated ? "" : "disabled"}>T</button>
        <button class="icon-btn ${viewMode === VIEW_MODE.ORIGINAL ? "active" : ""}" id="btn-view-original" title="\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B">O</button>
        <button class="icon-btn ${viewMode === VIEW_MODE.DIFF ? "active" : ""}" id="btn-view-diff" title="\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C diff" ${hasTranslated ? "" : "disabled"}>D</button>
      </div>
    </div>
  `;
  panel.querySelector("#btn-start")?.addEventListener("click", () => runStatusAction("start"));
  panel.querySelector("#btn-cancel")?.addEventListener("click", () => runStatusAction("cancel"));
  panel.querySelector("#btn-clear")?.addEventListener("click", () => runStatusAction("clear"));
  panel.querySelector("#btn-view-translation")?.addEventListener("click", () => switchView(VIEW_MODE.TRANSLATION));
  panel.querySelector("#btn-view-original")?.addEventListener("click", () => switchView(VIEW_MODE.ORIGINAL));
  panel.querySelector("#btn-view-diff")?.addEventListener("click", () => switchView(VIEW_MODE.DIFF));
  panel.querySelector("#error-pill")?.addEventListener("click", () => {
    state.eventFilters.onlyErrors = true;
    switchPanel("events");
    renderEventsPanel();
    refreshLogs().catch(() => {
    });
  });
}
async function runStatusAction(action) {
  try {
    if (action === "start") {
      state.uiState = mergeUiState(await callRuntime(MESSAGE.UI_START, { tabId: state.tabId, url: state.tabUrl }));
    } else if (action === "cancel") {
      state.uiState = mergeUiState(await callRuntime(MESSAGE.UI_CANCEL, { tabId: state.tabId }));
    } else if (action === "clear") {
      state.uiState = mergeUiState(await callRuntime(MESSAGE.UI_CLEAR, { tabId: state.tabId }));
    }
    renderStatusPanel();
    await refreshLogs();
  } catch (error) {
    setTransientError(error?.message || "Action failed");
    renderStatusPanel();
  }
}
async function switchView(mode) {
  const ui = mergeUiState(state.uiState);
  if (!ui.hasTranslatedBlocks && (mode === VIEW_MODE.TRANSLATION || mode === VIEW_MODE.DIFF)) {
    return;
  }
  try {
    state.uiState = mergeUiState(await callRuntime(MESSAGE.UI_SWITCH_VIEW, { tabId: state.tabId, mode }));
    renderStatusPanel();
  } catch (error) {
    setTransientError(error?.message || "View switch failed");
    renderStatusPanel();
  }
}
function renderSettingsPanel() {
  const panel = app.querySelector('[data-panel="settings"]');
  if (!panel || !state.settings) {
    return;
  }
  const activeProfileName = state.settings.activeProfileName || "default";
  const profileNames = Object.keys(state.profiles).sort((a, b) => a.localeCompare(b));
  const isDirty = isProfileDirty();
  const customSelected = isDirty ? "selected" : "";
  const profileOptions = profileNames.map((name) => `<option value="${escapeHtml(name)}" ${!isDirty && name === activeProfileName ? "selected" : ""}>${escapeHtml(name)}</option>`).join("");
  panel.innerHTML = `
    <div class="settings-grid">
      <div class="block">
        <div class="profile-toolbar">
          <select id="profile-select" title="\u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0439 \u043F\u0440\u043E\u0444\u0438\u043B\u044C">${profileOptions}<option value="${CUSTOM_PROFILE_OPTION}" ${customSelected}>*</option></select>
          <input id="profile-name" type="text" title="\u0418\u043C\u044F \u043F\u0440\u043E\u0444\u0438\u043B\u044F" placeholder="profile" value="${escapeHtml(state.profileNameDraft || "")}" autocomplete="off" />
          <button class="icon-btn" id="profile-save" title="\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043F\u0440\u043E\u0444\u0438\u043B\u044C">\u2913</button>
          <button class="icon-btn" id="settings-save" title="\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438">\u2713</button>
          <span id="profile-dirty-flag" class="right" title="\u041F\u0440\u043E\u0444\u0438\u043B\u044C \u0438\u0437\u043C\u0435\u043D\u0451\u043D">${isDirty ? "*" : ""}</span>
        </div>

        <textarea id="profile-json" title="JSON \u043F\u0440\u043E\u0444\u0438\u043B\u044F">${escapeHtml(toSortedJson(state.settings.profileDraft || {}))}</textarea>
        <div class="profile-fields" id="profile-fields"></div>

        <div class="editor-row" id="field-editor-row" hidden>
          <input id="field-editor-input" list="field-editor-list" autocomplete="off" />
          <button class="icon-btn" id="field-editor-apply" title="\u041F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C">\u2713</button>
          <button class="icon-btn" id="field-editor-close" title="\u0417\u0430\u043A\u0440\u044B\u0442\u044C">\u2715</button>
          <datalist id="field-editor-list"></datalist>
        </div>
      </div>

      <div class="block">
        <div class="access-switch" title="\u0420\u0435\u0436\u0438\u043C \u0434\u043E\u0441\u0442\u0443\u043F\u0430">
          <button id="mode-byok" class="${state.settings.accessMode === "BYOK" ? "active" : ""}">BYOK</button>
          <button id="mode-proxy" class="${state.settings.accessMode === "PROXY" ? "active" : ""}">PROXY</button>
        </div>

        <div id="access-byok" class="access-panel ${state.settings.accessMode === "BYOK" ? "active" : ""}">
          <div class="inline">
            <input type="password" id="byok-key" value="${escapeHtml(state.settings.byokApiKey || "")}" placeholder="API key" autocomplete="off" />
            <button class="icon-btn" id="toggle-byok-key" title="\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C/\u0441\u043A\u0440\u044B\u0442\u044C">\u25C9</button>
          </div>
          <input type="text" id="byok-url" value="${escapeHtml(state.settings.byokBaseUrl || "")}" placeholder="Base URL" autocomplete="off" />
        </div>

        <div id="access-proxy" class="access-panel ${state.settings.accessMode === "PROXY" ? "active" : ""}">
          <div class="inline">
            <input type="password" id="proxy-token" value="${escapeHtml(state.settings.proxyToken || "")}" placeholder="Proxy token" autocomplete="off" />
            <button class="icon-btn" id="toggle-proxy-token" title="\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C/\u0441\u043A\u0440\u044B\u0442\u044C">\u25C9</button>
          </div>
          <input type="text" id="proxy-url" value="${escapeHtml(state.settings.proxyBaseUrl || "")}" placeholder="Proxy URL" autocomplete="off" />
        </div>
      </div>

      <div class="block">
        <div class="models-toolbar">
          <button class="icon-btn" id="load-models" title="\u0417\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u043C\u043E\u0434\u0435\u043B\u0438">\u21BB</button>
          <select id="priority-context" title="\u041F\u0440\u0438\u043E\u0440\u0438\u0442\u0435\u0442 context"></select>
          <select id="priority-translation" title="\u041F\u0440\u0438\u043E\u0440\u0438\u0442\u0435\u0442 translation"></select>
        </div>
        <div id="models-list" class="models-list"></div>
      </div>
    </div>
  `;
  wireSettingsControls();
  renderProfileFields();
  renderModels();
}
function wireSettingsControls() {
  const profileSelect = app.querySelector("#profile-select");
  const profileNameInput = app.querySelector("#profile-name");
  const profileJson = app.querySelector("#profile-json");
  profileSelect?.addEventListener("change", () => {
    if (profileSelect.value === CUSTOM_PROFILE_OPTION) {
      return;
    }
    state.settings.activeProfileName = profileSelect.value;
    state.profileNameDraft = profileSelect.value;
    state.settings.profileDraft = deepClone(state.profiles[profileSelect.value] || DEFAULT_PROFILE_TEMPLATE);
    syncProfileDraftToSettings();
    renderSettingsPanel();
  });
  profileNameInput?.addEventListener("input", () => {
    state.profileNameDraft = profileNameInput.value;
  });
  app.querySelector("#profile-save")?.addEventListener("click", async () => {
    const name = normalizeProfileName(state.profileNameDraft, state.settings.activeProfileName);
    await callRuntime(MESSAGE.UI_SAVE_PROFILE, {
      name,
      profile: state.settings.profileDraft
    });
    state.profiles = await callRuntime(MESSAGE.UI_LIST_PROFILES);
    state.settings.activeProfileName = name;
    state.profileNameDraft = name;
    renderSettingsPanel();
  });
  app.querySelector("#settings-save")?.addEventListener("click", async () => {
    syncProfileDraftToSettings();
    state.settings = await callRuntime(MESSAGE.UI_SAVE_SETTINGS, { settings: state.settings });
    state.settings.profileDraft = deepClone(state.settings.profileDraft || state.profiles[state.settings.activeProfileName] || DEFAULT_PROFILE_TEMPLATE);
    renderSettingsPanel();
    await refreshState();
    await refreshLogs();
  });
  profileJson?.addEventListener("change", () => {
    try {
      state.settings.profileDraft = JSON.parse(profileJson.value);
      syncProfileDraftToSettings();
      renderProfileFields();
      profileJson.style.borderColor = "";
    } catch {
      profileJson.style.borderColor = "#111";
    }
  });
  app.querySelector("#mode-byok")?.addEventListener("click", () => {
    state.settings.accessMode = "BYOK";
    renderSettingsPanel();
  });
  app.querySelector("#mode-proxy")?.addEventListener("click", () => {
    state.settings.accessMode = "PROXY";
    renderSettingsPanel();
  });
  bindInput("#byok-key", (value) => {
    state.settings.byokApiKey = value;
  });
  bindInput("#byok-url", (value) => {
    state.settings.byokBaseUrl = value;
  });
  bindInput("#proxy-token", (value) => {
    state.settings.proxyToken = value;
  });
  bindInput("#proxy-url", (value) => {
    state.settings.proxyBaseUrl = value;
  });
  app.querySelector("#toggle-byok-key")?.addEventListener("click", () => togglePassword("#byok-key"));
  app.querySelector("#toggle-proxy-token")?.addEventListener("click", () => togglePassword("#proxy-token"));
  app.querySelector("#load-models")?.addEventListener("click", async () => {
    try {
      state.modelsCatalog = await callRuntime(MESSAGE.UI_LIST_MODELS);
      renderModels();
    } catch (error) {
      setTransientError(error?.message || "Failed to load models");
      renderStatusPanel();
    }
  });
}
function bindInput(selector, setter) {
  const element = app.querySelector(selector);
  element?.addEventListener("input", () => setter(element.value));
}
function togglePassword(selector) {
  const input = app.querySelector(selector);
  if (!input) {
    return;
  }
  input.type = input.type === "password" ? "text" : "password";
}
function renderProfileFields() {
  const list = app.querySelector("#profile-fields");
  if (!list) {
    return;
  }
  const selectedProfile = state.profiles[state.settings.activeProfileName] || {};
  const draft = state.settings.profileDraft || {};
  const rows = flattenLeafPaths(draft);
  list.innerHTML = rows.map(({ path, value }) => {
    const selectedValue = getValueByPath(selectedProfile, path);
    const changed = JSON.stringify(selectedValue) !== JSON.stringify(value);
    return `
        <button class="profile-field ${changed ? "changed" : ""}" data-path="${escapeHtml(path)}" title="${escapeHtml(path)}">
          <span>${escapeHtml(path)}</span>
          <span class="value-preview">${escapeHtml(formatValue(value))}</span>
        </button>
      `;
  }).join("");
  list.querySelectorAll(".profile-field").forEach((button) => {
    button.addEventListener("click", () => {
      openFieldEditor(button.dataset.path);
    });
  });
  const profileJson = app.querySelector("#profile-json");
  if (profileJson && document.activeElement !== profileJson) {
    profileJson.value = toSortedJson(draft);
  }
  const dirtyFlag = app.querySelector("#profile-dirty-flag");
  if (dirtyFlag) {
    dirtyFlag.textContent = isProfileDirty() ? "*" : "";
  }
  const profileSelect = app.querySelector("#profile-select");
  if (profileSelect) {
    const dirty = isProfileDirty();
    profileSelect.value = dirty ? CUSTOM_PROFILE_OPTION : state.settings.activeProfileName || "default";
  }
}
function openFieldEditor(path) {
  const row = app.querySelector("#field-editor-row");
  const input = app.querySelector("#field-editor-input");
  const datalist = app.querySelector("#field-editor-list");
  const applyButton = app.querySelector("#field-editor-apply");
  const closeButton = app.querySelector("#field-editor-close");
  if (!row || !input || !datalist || !applyButton || !closeButton) {
    return;
  }
  state.fieldEditor.path = path;
  const meta = PROFILE_FIELD_META[path] || null;
  const currentValue = getValueByPath(state.settings.profileDraft, path);
  datalist.innerHTML = "";
  if (Array.isArray(meta?.enum)) {
    datalist.innerHTML = meta.enum.map((value) => `<option value="${escapeHtml(String(value))}"></option>`).join("");
  }
  input.value = formatValue(currentValue);
  input.title = path;
  row.hidden = false;
  input.focus();
  const commit = () => {
    const editorPath = state.fieldEditor.path;
    const parsed = parseFieldValue(input.value, meta);
    setValueByPath(state.settings.profileDraft, editorPath, parsed);
    syncProfileDraftToSettings();
    renderSettingsPanel();
  };
  applyButton.onclick = commit;
  closeButton.onclick = () => {
    row.hidden = true;
    state.fieldEditor.path = "";
  };
  input.onkeydown = (event) => {
    if (event.key === "Enter") {
      commit();
    }
    if (event.key === "Escape") {
      row.hidden = true;
      state.fieldEditor.path = "";
    }
  };
}
function syncProfileDraftToSettings() {
  const draft = state.settings.profileDraft || {};
  for (const key of Object.keys(draft)) {
    state.settings[key] = deepClone(draft[key]);
  }
}
function captureProfileDraftFromSettings() {
  const draft = {};
  for (const key of Object.keys(DEFAULT_PROFILE_TEMPLATE)) {
    draft[key] = deepClone(state.settings[key]);
  }
  state.settings.profileDraft = draft;
}
function isProfileDirty() {
  const selectedProfile = state.profiles[state.settings.activeProfileName] || {};
  const draft = state.settings.profileDraft || {};
  return JSON.stringify(selectedProfile) !== JSON.stringify(draft);
}
function renderModels() {
  const list = app.querySelector("#models-list");
  const contextSelect = app.querySelector("#priority-context");
  const translationSelect = app.querySelector("#priority-translation");
  if (!list || !contextSelect || !translationSelect) {
    return;
  }
  if (!state.settings.models) {
    state.settings.models = { selected: [] };
  }
  if (!Array.isArray(state.settings.models.selected)) {
    state.settings.models.selected = [];
  }
  if (!state.settings.modelPriority) {
    state.settings.modelPriority = { context: [], translation: [] };
  }
  const selectedSet = new Set(state.settings.models.selected);
  const source = state.modelsCatalog.length > 0 ? [...state.modelsCatalog] : state.settings.models.selected.map((id) => ({ id, pricing: null, totalPricePer1M: Number.POSITIVE_INFINITY }));
  source.sort((left, right) => {
    const leftPrice = Number.isFinite(left.totalPricePer1M) ? left.totalPricePer1M : left.pricing ? Number(left.pricing.input || 0) + Number(left.pricing.output || 0) : Number.POSITIVE_INFINITY;
    const rightPrice = Number.isFinite(right.totalPricePer1M) ? right.totalPricePer1M : right.pricing ? Number(right.pricing.input || 0) + Number(right.pricing.output || 0) : Number.POSITIVE_INFINITY;
    return leftPrice - rightPrice || String(left.id).localeCompare(String(right.id));
  });
  list.innerHTML = source.map((model) => {
    const checked = selectedSet.has(model.id) ? "checked" : "";
    const priceText = model.pricing ? `i:${model.pricing.input} o:${model.pricing.output} c:${model.pricing.cachedInput}` : "i:- o:- c:-";
    return `
        <label class="model-item">
          <input type="checkbox" data-model-id="${escapeHtml(model.id)}" ${checked} />
          <span title="input/output/cached per 1M">${escapeHtml(model.id)} (${escapeHtml(priceText)})</span>
        </label>
      `;
  }).join("");
  list.querySelectorAll("input[type='checkbox']").forEach((checkbox) => {
    checkbox.addEventListener("change", () => {
      const modelId = checkbox.dataset.modelId;
      if (checkbox.checked) {
        if (!state.settings.models.selected.includes(modelId)) {
          state.settings.models.selected.push(modelId);
        }
      } else {
        state.settings.models.selected = state.settings.models.selected.filter((id) => id !== modelId);
      }
      normalizeModelPriorities();
      captureProfileDraftFromSettings();
      renderModels();
      renderProfileFields();
    });
  });
  const options = state.settings.models.selected.map((id) => `<option value="${escapeHtml(id)}">${escapeHtml(id)}</option>`).join("");
  contextSelect.innerHTML = options;
  translationSelect.innerHTML = options;
  normalizeModelPriorities();
  contextSelect.value = state.settings.modelPriority.context[0] || "";
  translationSelect.value = state.settings.modelPriority.translation[0] || "";
  contextSelect.onchange = () => {
    reorderPriority("context", contextSelect.value);
  };
  translationSelect.onchange = () => {
    reorderPriority("translation", translationSelect.value);
  };
}
function normalizeModelPriorities() {
  const selected = state.settings.models.selected;
  const priority = state.settings.modelPriority;
  priority.context = (priority.context || []).filter((id) => selected.includes(id));
  priority.translation = (priority.translation || []).filter((id) => selected.includes(id));
  const first = selected[0] || "";
  if (first && priority.context.length === 0) {
    priority.context.push(first);
  }
  if (first && priority.translation.length === 0) {
    priority.translation.push(first);
  }
}
function reorderPriority(key, modelId) {
  if (!modelId || !state.settings.modelPriority?.[key]) {
    return;
  }
  state.settings.modelPriority[key] = [modelId, ...state.settings.modelPriority[key].filter((id) => id !== modelId)];
  captureProfileDraftFromSettings();
  renderProfileFields();
}
function renderEventsPanel(logData = null) {
  const panel = app.querySelector('[data-panel="events"]');
  if (!panel) {
    return;
  }
  if (!panel.dataset.ready) {
    panel.innerHTML = `
      <div class="events-toolbar">
        <select id="event-category" title="\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F">
          <option value="">all</option>
          ${Object.values(EVENT_CATEGORY).map((category) => `<option value="${escapeHtml(category)}">${escapeHtml(category)}</option>`).join("")}
        </select>
        <button class="icon-btn" id="event-errors-only" title="\u0422\u043E\u043B\u044C\u043A\u043E \u043E\u0448\u0438\u0431\u043A\u0438">!</button>
        <button class="icon-btn" id="event-download" title="\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u043B\u043E\u0433">\u2193</button>
        <button class="icon-btn" id="event-copy" title="\u041A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043B\u043E\u0433">\u2398</button>
      </div>
      <div id="logs" class="logs"></div>
    `;
    panel.dataset.ready = "1";
    panel.querySelector("#event-category")?.addEventListener("change", async (event) => {
      state.eventFilters.category = event.target.value;
      await refreshLogs();
    });
    panel.querySelector("#event-errors-only")?.addEventListener("click", async () => {
      state.eventFilters.onlyErrors = !state.eventFilters.onlyErrors;
      await refreshLogs();
    });
    panel.querySelector("#event-download")?.addEventListener("click", downloadLogs);
    panel.querySelector("#event-copy")?.addEventListener("click", copyLogs);
  }
  panel.querySelector("#event-category").value = state.eventFilters.category;
  panel.querySelector("#event-errors-only")?.classList.toggle("active", state.eventFilters.onlyErrors);
  if (!logData) {
    return;
  }
  panel.querySelector("#logs").innerHTML = logData.items.map((row) => {
    const summary = `${row.ts} | ${row.level} | ${row.category} | ${row.name}`;
    const payload = JSON.stringify(
      {
        pageSessionId: row.pageSessionId,
        tabId: row.tabId,
        batchId: row.batchId,
        blockId: row.blockId,
        data: row.data,
        error: row.error
      },
      null,
      2
    );
    return `<details><summary>${escapeHtml(summary)}</summary><pre>${escapeHtml(payload)}</pre></details>`;
  }).join("");
}
async function refreshLogs() {
  renderEventsPanel();
  const logs = await callRuntime(MESSAGE.LOG_QUERY, {
    filters: {
      ...state.eventFilters,
      pageSessionId: state.uiState?.pageSessionId || null,
      limit: 400
    }
  });
  renderEventsPanel(logs);
}
async function downloadLogs() {
  const json = await callRuntime(MESSAGE.LOG_EXPORT, {
    filters: {
      ...state.eventFilters,
      pageSessionId: state.uiState?.pageSessionId || null
    }
  });
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  await chrome.downloads.download({
    url,
    filename: `neuro-translate-log-${Date.now()}.json`,
    saveAs: true
  });
  setTimeout(() => URL.revokeObjectURL(url), 1e3);
}
async function copyLogs() {
  const json = await callRuntime(MESSAGE.LOG_EXPORT, {
    filters: {
      ...state.eventFilters,
      pageSessionId: state.uiState?.pageSessionId || null
    }
  });
  await navigator.clipboard.writeText(json);
}
async function openDebugPage() {
  const url = chrome.runtime.getURL("debug/debug.html");
  await chrome.tabs.create({ url });
}
function normalizeProfileName(rawName, fallbackName) {
  const normalized = String(rawName || "").trim();
  if (normalized) {
    return normalized;
  }
  const fallback = String(fallbackName || "").trim();
  if (fallback) {
    return fallback;
  }
  return `profile-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}`;
}
function canRunOnCurrentTab() {
  return Number.isInteger(state.tabId) && /^https?:/i.test(state.tabUrl || "");
}
function setTransientError(message) {
  const next = mergeUiState(state.uiState);
  next.lastError = { message };
  state.uiState = next;
}
function flattenLeafPaths(obj, prefix = "") {
  const rows = [];
  for (const [key, value] of Object.entries(obj || {})) {
    const path = prefix ? `${prefix}.${key}` : key;
    if (value && typeof value === "object" && !Array.isArray(value)) {
      rows.push(...flattenLeafPaths(value, path));
      continue;
    }
    rows.push({ path, value });
  }
  return rows;
}
function formatValue(value) {
  if (typeof value === "string") {
    return value;
  }
  return JSON.stringify(value);
}
function parseFieldValue(raw, meta) {
  if (!meta) {
    return parseFallback(raw);
  }
  switch (meta.type) {
    case "boolean":
      return raw === "true";
    case "number":
      return Number(raw);
    case "array":
      try {
        return JSON.parse(raw);
      } catch {
        return raw.split(",").map((part) => part.trim()).filter(Boolean);
      }
    default:
      return raw;
  }
}
function parseFallback(raw) {
  if (raw === "true") {
    return true;
  }
  if (raw === "false") {
    return false;
  }
  const num = Number(raw);
  if (raw.trim() !== "" && Number.isFinite(num)) {
    return num;
  }
  if (raw.startsWith("{") && raw.endsWith("}") || raw.startsWith("[") && raw.endsWith("]")) {
    try {
      return JSON.parse(raw);
    } catch {
      return raw;
    }
  }
  return raw;
}
function escapeHtml(text) {
  return String(text).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#39;");
}
//# sourceMappingURL=popup.js.map

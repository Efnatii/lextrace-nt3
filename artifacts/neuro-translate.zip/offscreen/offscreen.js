// src/shared/constants.js
var MESSAGE = Object.freeze({
  UI_START: "ui.start",
  UI_CANCEL: "ui.cancel",
  UI_CLEAR: "ui.clear",
  UI_SWITCH_VIEW: "ui.switch_view",
  UI_STATE: "ui.state",
  UI_PING: "ui.ping",
  UI_LOAD_SETTINGS: "ui.load_settings",
  UI_SAVE_SETTINGS: "ui.save_settings",
  UI_SAVE_PROFILE: "ui.save_profile",
  UI_LIST_MODELS: "ui.list_models",
  UI_LIST_PROFILES: "ui.list_profiles",
  LOG_QUERY: "log.query",
  LOG_EXPORT: "log.export",
  LOG_CLEAR: "log.clear",
  CONTENT_SCAN: "content.scan",
  CONTENT_APPLY_BATCH: "content.apply_batch",
  CONTENT_SWITCH_VIEW: "content.switch_view",
  CONTENT_CLEAR: "content.clear",
  OFFSCREEN_EXECUTE: "offscreen.execute",
  OFFSCREEN_CANCEL: "offscreen.cancel",
  PIPELINE_RESUME: "pipeline.resume"
});
var VIEW_MODE = Object.freeze({
  TRANSLATION: "translation",
  ORIGINAL: "original",
  DIFF: "diff"
});
var PIPELINE_STAGE = Object.freeze({
  IDLE: "idle",
  SCANNING: "scanning",
  CONTEXT: "context",
  BATCHING: "batching",
  TRANSLATING: "translating",
  APPLYING: "applying",
  DONE: "done",
  CANCELLED: "cancelled",
  FAILED: "failed"
});
var LOG_LEVEL = Object.freeze({
  DEBUG: "debug",
  INFO: "info",
  WARN: "warn",
  ERROR: "error"
});
var EVENT_CATEGORY = Object.freeze({
  UI_ACTION: "ui.action",
  PIPELINE_STAGE: "pipeline.stage",
  DOM_SCAN: "dom.scan",
  DOM_CLASSIFY: "dom.classify",
  DOM_APPLY: "dom.apply",
  CONTEXT_GENERATE: "context.generate",
  CONTEXT_COMPACT: "context.compact",
  BATCH_CREATE: "batch.create",
  BATCH_TRANSLATE: "batch.translate",
  OPENAI_REQUEST: "openai.request",
  OPENAI_RESPONSE: "openai.response",
  OPENAI_RATE_LIMIT: "openai.rate_limit",
  CANCELLATION: "cancellation",
  STORAGE_GC: "storage.gc",
  ERROR: "error"
});
var STORAGE_KEYS = Object.freeze({
  SETTINGS: "settings",
  PROFILES: "profiles",
  TAB_STATES: "tabStates",
  ACTIVE_SESSION_BY_TAB: "activeSessionByTab"
});
var DEFAULT_SETTINGS = Object.freeze({
  activeProfileName: "default",
  selectedViewMode: VIEW_MODE.ORIGINAL,
  accessMode: "BYOK",
  byokApiKey: "",
  byokBaseUrl: "https://api.openai.com/v1",
  proxyToken: "",
  proxyBaseUrl: "",
  promptCaching: {
    enabled: true,
    scope: "profile"
  },
  globalContext: {
    targetTokens: 15e3,
    maxOutputTokens: 4096,
    model: "gpt-4.1-mini"
  },
  batching: {
    blockLimits: {
      minChars: 1,
      maxChars: 2800
    },
    batchTokenTarget: 1200,
    maxBlocksPerBatch: 24
  },
  batchWindow: {
    prevBatchesCount: 3,
    compactAfter: 8,
    compactPolicy: "rolling"
  },
  compaction: {
    model: "gpt-4.1-mini",
    prompt: "Compact translated history preserving terms and entities.",
    thresholds: {
      tokenTarget: 450,
      startAfterBatch: 8
    }
  },
  storagePolicy: {
    whatToKeep: "full",
    maxBytes: 3e6,
    maxRecords: 8e3,
    maxAgeMs: 1e3 * 60 * 60 * 24 * 7,
    gcPolicy: "lru"
  },
  models: {
    selected: ["gpt-4.1-mini", "gpt-4.1-nano"],
    sortablePricing: true
  },
  modelPriority: {
    context: ["gpt-4.1-mini", "gpt-4.1-nano"],
    translation: ["gpt-4.1-mini", "gpt-4.1-nano"]
  },
  rateLimits: {
    safetyBufferTokens: 500,
    perModel: {
      "gpt-4.1-mini": { tpm: 18e4, rpm: 500, concurrency: 3 },
      "gpt-4.1-nano": { tpm: 3e5, rpm: 600, concurrency: 4 }
    }
  },
  mockMode: {
    enabled: false,
    artificialDelayMs: 120,
    forceError: false
  }
});
var DEFAULT_PROFILE_TEMPLATE = Object.freeze({
  promptCaching: { ...DEFAULT_SETTINGS.promptCaching },
  globalContext: { ...DEFAULT_SETTINGS.globalContext },
  batching: { ...DEFAULT_SETTINGS.batching },
  batchWindow: { ...DEFAULT_SETTINGS.batchWindow },
  compaction: { ...DEFAULT_SETTINGS.compaction },
  storagePolicy: { ...DEFAULT_SETTINGS.storagePolicy },
  models: { ...DEFAULT_SETTINGS.models },
  modelPriority: { ...DEFAULT_SETTINGS.modelPriority },
  rateLimits: { ...DEFAULT_SETTINGS.rateLimits }
});
var MODEL_PRICE_CATALOG = Object.freeze({
  "gpt-4.1": { input: 10, output: 30, cachedInput: 2.5 },
  "gpt-4.1-mini": { input: 0.8, output: 3.2, cachedInput: 0.2 },
  "gpt-4.1-nano": { input: 0.2, output: 0.8, cachedInput: 0.05 },
  "gpt-5": { input: 15, output: 45, cachedInput: 3.75 },
  "gpt-5-mini": { input: 1.2, output: 4.8, cachedInput: 0.3 },
  "gpt-5-nano": { input: 0.4, output: 1.6, cachedInput: 0.1 }
});

// src/shared/utils.js
function parseRetryAfterSeconds(headers) {
  if (!headers || typeof headers.get !== "function") {
    return null;
  }
  const raw = headers.get("retry-after");
  if (!raw) {
    return null;
  }
  const seconds = Number.parseInt(raw, 10);
  if (Number.isFinite(seconds)) {
    return Math.max(0, seconds);
  }
  const parsedDate = Date.parse(raw);
  if (Number.isFinite(parsedDate)) {
    const delayMs = parsedDate - Date.now();
    return Math.max(0, Math.ceil(delayMs / 1e3));
  }
  return null;
}

// src/shared/rate-limit-controller.js
var RateLimitError = class extends Error {
  constructor(message, { retryAfterMs = 0, status = 429 } = {}) {
    super(message);
    this.name = "RateLimitError";
    this.retryAfterMs = retryAfterMs;
    this.status = status;
  }
};

// src/shared/translation-schema.js
var REQUIRED_TRANSLATION_KEYS = ["batchId", "translations"];
var TOP_LEVEL_KEYS = /* @__PURE__ */ new Set(["batchId", "sourceLang", "targetLang", "glossaryHints", "qualityFlags", "translations"]);
var ROW_KEYS = /* @__PURE__ */ new Set(["blockId", "translatedText", "warnings"]);
var TRANSLATION_JSON_SCHEMA = Object.freeze({
  type: "object",
  additionalProperties: false,
  required: REQUIRED_TRANSLATION_KEYS,
  properties: {
    batchId: { type: "string" },
    sourceLang: { type: "string" },
    targetLang: { type: "string" },
    glossaryHints: { type: "array", items: { type: "string" } },
    qualityFlags: { type: "array", items: { type: "string" } },
    translations: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["blockId", "translatedText"],
        properties: {
          blockId: { type: "string" },
          translatedText: { type: "string" },
          warnings: { type: "array", items: { type: "string" } }
        }
      }
    }
  }
});
function validateStructuredTranslation(payload) {
  if (!payload || typeof payload !== "object") {
    throw new Error("Structured output must be an object");
  }
  for (const key of Object.keys(payload)) {
    if (!TOP_LEVEL_KEYS.has(key)) {
      throw new Error(`Structured output contains unsupported key: ${key}`);
    }
  }
  for (const key of REQUIRED_TRANSLATION_KEYS) {
    if (!(key in payload)) {
      throw new Error(`Structured output missing key: ${key}`);
    }
  }
  if (typeof payload.batchId !== "string" || !payload.batchId) {
    throw new Error("Structured output batchId must be a non-empty string");
  }
  if (payload.sourceLang !== void 0 && typeof payload.sourceLang !== "string") {
    throw new Error("Structured output sourceLang must be a string");
  }
  if (payload.targetLang !== void 0 && typeof payload.targetLang !== "string") {
    throw new Error("Structured output targetLang must be a string");
  }
  if (payload.glossaryHints !== void 0) {
    if (!Array.isArray(payload.glossaryHints) || payload.glossaryHints.some((item) => typeof item !== "string")) {
      throw new Error("Structured output glossaryHints must be an array of strings");
    }
  }
  if (payload.qualityFlags !== void 0) {
    if (!Array.isArray(payload.qualityFlags) || payload.qualityFlags.some((item) => typeof item !== "string")) {
      throw new Error("Structured output qualityFlags must be an array of strings");
    }
  }
  if (!Array.isArray(payload.translations)) {
    throw new Error("Structured output translations must be an array");
  }
  for (const row of payload.translations) {
    if (!row || typeof row !== "object") {
      throw new Error("Each translation row must be an object");
    }
    for (const key of Object.keys(row)) {
      if (!ROW_KEYS.has(key)) {
        throw new Error(`Translation row contains unsupported key: ${key}`);
      }
    }
    if (typeof row.blockId !== "string" || !row.blockId) {
      throw new Error("Translation row missing blockId");
    }
    if (typeof row.translatedText !== "string") {
      throw new Error("Translation row missing translatedText");
    }
    if (row.warnings !== void 0) {
      if (!Array.isArray(row.warnings) || row.warnings.some((item) => typeof item !== "string")) {
        throw new Error("Translation row warnings must be an array of strings");
      }
    }
  }
  return payload;
}

// src/offscreen/offscreen.js
var inflight = /* @__PURE__ */ new Map();
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  Promise.resolve().then(async () => {
    switch (message?.type) {
      case MESSAGE.OFFSCREEN_EXECUTE:
        return runOperation(message.payload);
      case MESSAGE.OFFSCREEN_CANCEL:
        return cancelRequest(message.requestId, message.pageSessionId);
      default:
        return null;
    }
  }).then((result) => sendResponse({ ok: true, result })).catch((error) => {
    sendResponse({
      ok: false,
      error: error?.message || String(error),
      status: error?.status,
      retryAfterMs: error?.retryAfterMs || 0
    });
  });
  return true;
});
async function runOperation(payload) {
  if (!payload?.operation) {
    throw new Error("Offscreen payload missing operation");
  }
  switch (payload.operation) {
    case "openai.responses":
      return runResponses(payload);
    case "openai.models":
      return runModels(payload);
    default:
      throw new Error(`Unsupported offscreen operation: ${payload.operation}`);
  }
}
function createHeaders(access) {
  const headers = {
    "Content-Type": "application/json"
  };
  if (access?.mode === "PROXY") {
    headers.Authorization = `Bearer ${access.token}`;
  } else {
    headers.Authorization = `Bearer ${access.apiKey}`;
  }
  return headers;
}
async function runResponses({ requestId, pageSessionId, payload, access }) {
  const mockMode = payload?.mockMode?.enabled;
  const delayMs = payload?.mockMode?.artificialDelayMs || 0;
  if (mockMode) {
    if (payload?.mockMode?.forceError && payload?.role === "translation") {
      const error = new Error("Mock translation error");
      error.status = 500;
      throw error;
    }
    if (delayMs > 0) {
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
    return mockResponses(payload);
  }
  const controller = new AbortController();
  inflight.set(requestId, {
    controller,
    pageSessionId: pageSessionId || null
  });
  try {
    const baseUrl = String(access?.baseUrl || "https://api.openai.com/v1").replace(/\/$/, "");
    const endpoint = `${baseUrl}/responses`;
    const body = buildResponsesBody(payload);
    const response = await fetch(endpoint, {
      method: "POST",
      headers: createHeaders(access),
      body: JSON.stringify(body),
      signal: controller.signal
    });
    if (response.status === 429) {
      const retryAfterSeconds = parseRetryAfterSeconds(response.headers);
      throw new RateLimitError("Rate limit reached", {
        retryAfterMs: (retryAfterSeconds || 1) * 1e3,
        status: 429
      });
    }
    if (!response.ok) {
      const text = await response.text();
      const error = new Error(`OpenAI HTTP ${response.status}: ${text.slice(0, 600)}`);
      error.status = response.status;
      throw error;
    }
    const json = await response.json();
    return normalizeResponsesPayload(payload, json);
  } finally {
    inflight.delete(requestId);
  }
}
function buildResponsesBody(payload) {
  const role = payload.role;
  const model = payload.model;
  if (role === "context") {
    const targetTokens = Math.max(15e3, Number(payload?.input?.targetTokens) || 15e3);
    const maxOutputTokens = Math.max(512, Number(payload?.input?.maxOutputTokens) || 4096);
    const passIndex = Number(payload?.input?.passIndex || 0);
    const passCount = Number(payload?.input?.passCount || 1);
    const previousTail = String(payload?.input?.previousContextTail || "");
    return {
      model,
      temperature: 0.2,
      max_output_tokens: maxOutputTokens,
      input: [
        {
          role: "system",
          content: [
            {
              type: "input_text",
              text: "You produce exhaustive global translation context. Build detailed, high-density notes for consistent translation quality. Include domain assumptions, named entities, glossary hints, consistency constraints, style and ambiguity handling. Return plain text only."
            }
          ]
        },
        {
          role: "user",
          content: [
            {
              type: "input_text",
              text: JSON.stringify({
                targetTokens,
                maxOutputTokens,
                passIndex,
                passCount,
                previousContextTail,
                orderedBlocks: payload.input?.orderedBlocks || ""
              })
            }
          ]
        }
      ]
    };
  }
  return {
    model,
    temperature: 0.1,
    text: {
      format: {
        type: "json_schema",
        name: "translation_output",
        strict: true,
        schema: TRANSLATION_JSON_SCHEMA
      }
    },
    input: [
      {
        role: "system",
        content: [
          {
            type: "input_text",
            text: "Translate each block preserving semantics, entities, formatting intent, and consistency with global context/history. Output strictly valid JSON matching schema."
          }
        ]
      },
      {
        role: "user",
        content: [
          {
            type: "input_text",
            text: JSON.stringify(payload.input)
          }
        ]
      }
    ]
  };
}
function normalizeResponsesPayload(payload, json) {
  const text = readOutputText(json);
  const usage = readUsage(json);
  if (payload.role === "context") {
    return {
      text,
      structured: {
        context: text
      },
      usage,
      raw: json
    };
  }
  const structured = parseJsonStrict(text);
  validateStructuredTranslation(structured);
  return {
    text,
    structured,
    usage,
    raw: json
  };
}
function readUsage(json) {
  const usage = json?.usage || {};
  const inputTokens = Number.isFinite(Number(usage.input_tokens)) ? Number(usage.input_tokens) : null;
  const outputTokens = Number.isFinite(Number(usage.output_tokens)) ? Number(usage.output_tokens) : null;
  const totalTokens = Number.isFinite(Number(usage.total_tokens)) ? Number(usage.total_tokens) : null;
  const cachedInputTokens = Number.isFinite(Number(usage?.input_tokens_details?.cached_tokens)) ? Number(usage.input_tokens_details.cached_tokens) : null;
  if (inputTokens === null && outputTokens === null && totalTokens === null && cachedInputTokens === null) {
    return null;
  }
  return {
    inputTokens,
    outputTokens,
    totalTokens,
    cachedInputTokens
  };
}
function readOutputText(json) {
  if (typeof json?.output_text === "string" && json.output_text) {
    return json.output_text;
  }
  const output = Array.isArray(json?.output) ? json.output : [];
  for (const item of output) {
    const content = Array.isArray(item?.content) ? item.content : [];
    for (const chunk of content) {
      if (typeof chunk?.text === "string") {
        return chunk.text;
      }
      if (typeof chunk?.output_text === "string") {
        return chunk.output_text;
      }
    }
  }
  return "";
}
function parseJsonStrict(text) {
  if (!text || typeof text !== "string") {
    throw new Error("Structured output missing JSON text");
  }
  try {
    return JSON.parse(text);
  } catch {
    throw new Error("Structured output is not valid JSON");
  }
}
function mockResponses(payload) {
  if (payload.role === "context") {
    return {
      text: `Mock global context for ${payload.pageSessionId}`,
      structured: {
        context: `Mock context for ${payload.pageSessionId}`
      }
    };
  }
  const blocks = payload.input?.blocks || [];
  const structured = {
    batchId: payload.batchId,
    sourceLang: "auto",
    targetLang: "ru",
    glossaryHints: [],
    qualityFlags: ["mock"],
    translations: blocks.map((block) => ({
      blockId: block.blockId,
      translatedText: `[RU] ${block.text}`,
      warnings: []
    }))
  };
  validateStructuredTranslation(structured);
  return {
    text: JSON.stringify(structured),
    structured
  };
}
async function runModels({ access, payload }) {
  const baseUrl = String(access?.baseUrl || payload?.baseUrl || "https://api.openai.com/v1").replace(/\/$/, "");
  const endpoint = `${baseUrl}/models`;
  const response = await fetch(endpoint, {
    method: "GET",
    headers: createHeaders(access)
  });
  if (!response.ok) {
    throw new Error(`Failed to list models. HTTP ${response.status}`);
  }
  const json = await response.json();
  const models = Array.isArray(json.data) ? json.data : [];
  const sorted = models.map((item) => {
    const pricing = MODEL_PRICE_CATALOG[item.id] || null;
    return {
      id: item.id,
      ownedBy: item.owned_by,
      pricing,
      totalPricePer1M: pricing ? pricing.input + pricing.output : Number.POSITIVE_INFINITY
    };
  }).sort((a, b) => a.totalPricePer1M - b.totalPricePer1M || a.id.localeCompare(b.id));
  return {
    models: sorted
  };
}
function cancelRequest(requestId, pageSessionId) {
  if (requestId) {
    const entry = inflight.get(requestId);
    if (entry?.controller) {
      entry.controller.abort();
      inflight.delete(requestId);
    } else if (typeof entry?.abort === "function") {
      entry.abort();
      inflight.delete(requestId);
    }
    return { cancelledRequestId: requestId };
  }
  if (pageSessionId) {
    for (const [id, entry] of inflight.entries()) {
      const entrySessionId = entry?.pageSessionId || null;
      if (entrySessionId === pageSessionId) {
        entry.controller?.abort?.();
        inflight.delete(id);
      }
    }
    return { cancelledSession: pageSessionId };
  }
  return { cancelledRequestId: null };
}
//# sourceMappingURL=offscreen.js.map

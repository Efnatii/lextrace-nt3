// src/shared/constants.js
var MESSAGE = Object.freeze({
  UI_START: "ui.start",
  UI_CANCEL: "ui.cancel",
  UI_CLEAR: "ui.clear",
  UI_SWITCH_VIEW: "ui.switch_view",
  UI_STATE: "ui.state",
  UI_PING: "ui.ping",
  UI_LOAD_SETTINGS: "ui.load_settings",
  UI_SAVE_SETTINGS: "ui.save_settings",
  UI_SAVE_PROFILE: "ui.save_profile",
  UI_LIST_MODELS: "ui.list_models",
  UI_LIST_PROFILES: "ui.list_profiles",
  LOG_QUERY: "log.query",
  LOG_EXPORT: "log.export",
  LOG_CLEAR: "log.clear",
  CONTENT_SCAN: "content.scan",
  CONTENT_APPLY_BATCH: "content.apply_batch",
  CONTENT_SWITCH_VIEW: "content.switch_view",
  CONTENT_CLEAR: "content.clear",
  OFFSCREEN_EXECUTE: "offscreen.execute",
  OFFSCREEN_CANCEL: "offscreen.cancel",
  PIPELINE_RESUME: "pipeline.resume"
});
var VIEW_MODE = Object.freeze({
  TRANSLATION: "translation",
  ORIGINAL: "original",
  DIFF: "diff"
});
var PIPELINE_STAGE = Object.freeze({
  IDLE: "idle",
  SCANNING: "scanning",
  CONTEXT: "context",
  BATCHING: "batching",
  TRANSLATING: "translating",
  APPLYING: "applying",
  DONE: "done",
  CANCELLED: "cancelled",
  FAILED: "failed"
});
var LOG_LEVEL = Object.freeze({
  DEBUG: "debug",
  INFO: "info",
  WARN: "warn",
  ERROR: "error"
});
var EVENT_CATEGORY = Object.freeze({
  UI_ACTION: "ui.action",
  PIPELINE_STAGE: "pipeline.stage",
  DOM_SCAN: "dom.scan",
  DOM_CLASSIFY: "dom.classify",
  DOM_APPLY: "dom.apply",
  CONTEXT_GENERATE: "context.generate",
  CONTEXT_COMPACT: "context.compact",
  BATCH_CREATE: "batch.create",
  BATCH_TRANSLATE: "batch.translate",
  OPENAI_REQUEST: "openai.request",
  OPENAI_RESPONSE: "openai.response",
  OPENAI_RATE_LIMIT: "openai.rate_limit",
  CANCELLATION: "cancellation",
  STORAGE_GC: "storage.gc",
  ERROR: "error"
});
var STORAGE_KEYS = Object.freeze({
  SETTINGS: "settings",
  PROFILES: "profiles",
  TAB_STATES: "tabStates",
  ACTIVE_SESSION_BY_TAB: "activeSessionByTab"
});
var DEFAULT_SETTINGS = Object.freeze({
  activeProfileName: "default",
  selectedViewMode: VIEW_MODE.ORIGINAL,
  accessMode: "BYOK",
  byokApiKey: "",
  byokBaseUrl: "https://api.openai.com/v1",
  proxyToken: "",
  proxyBaseUrl: "",
  promptCaching: {
    enabled: true,
    scope: "profile"
  },
  globalContext: {
    targetTokens: 15e3,
    maxOutputTokens: 4096,
    model: "gpt-4.1-mini"
  },
  batching: {
    blockLimits: {
      minChars: 1,
      maxChars: 2800
    },
    batchTokenTarget: 1200,
    maxBlocksPerBatch: 24
  },
  batchWindow: {
    prevBatchesCount: 3,
    compactAfter: 8,
    compactPolicy: "rolling"
  },
  compaction: {
    model: "gpt-4.1-mini",
    prompt: "Compact translated history preserving terms and entities.",
    thresholds: {
      tokenTarget: 450,
      startAfterBatch: 8
    }
  },
  storagePolicy: {
    whatToKeep: "full",
    maxBytes: 3e6,
    maxRecords: 8e3,
    maxAgeMs: 1e3 * 60 * 60 * 24 * 7,
    gcPolicy: "lru"
  },
  models: {
    selected: ["gpt-4.1-mini", "gpt-4.1-nano"],
    sortablePricing: true
  },
  modelPriority: {
    context: ["gpt-4.1-mini", "gpt-4.1-nano"],
    translation: ["gpt-4.1-mini", "gpt-4.1-nano"]
  },
  rateLimits: {
    safetyBufferTokens: 500,
    perModel: {
      "gpt-4.1-mini": { tpm: 18e4, rpm: 500, concurrency: 3 },
      "gpt-4.1-nano": { tpm: 3e5, rpm: 600, concurrency: 4 }
    }
  },
  mockMode: {
    enabled: false,
    artificialDelayMs: 120,
    forceError: false
  }
});
var DEFAULT_PROFILE_TEMPLATE = Object.freeze({
  promptCaching: { ...DEFAULT_SETTINGS.promptCaching },
  globalContext: { ...DEFAULT_SETTINGS.globalContext },
  batching: { ...DEFAULT_SETTINGS.batching },
  batchWindow: { ...DEFAULT_SETTINGS.batchWindow },
  compaction: { ...DEFAULT_SETTINGS.compaction },
  storagePolicy: { ...DEFAULT_SETTINGS.storagePolicy },
  models: { ...DEFAULT_SETTINGS.models },
  modelPriority: { ...DEFAULT_SETTINGS.modelPriority },
  rateLimits: { ...DEFAULT_SETTINGS.rateLimits }
});
var MODEL_PRICE_CATALOG = Object.freeze({
  "gpt-4.1": { input: 10, output: 30, cachedInput: 2.5 },
  "gpt-4.1-mini": { input: 0.8, output: 3.2, cachedInput: 0.2 },
  "gpt-4.1-nano": { input: 0.2, output: 0.8, cachedInput: 0.05 },
  "gpt-5": { input: 15, output: 45, cachedInput: 3.75 },
  "gpt-5-mini": { input: 1.2, output: 4.8, cachedInput: 0.3 },
  "gpt-5-nano": { input: 0.4, output: 1.6, cachedInput: 0.1 }
});

// src/shared/runtime-api.js
async function callRuntime(type, payload = {}) {
  const response = await chrome.runtime.sendMessage({ type, ...payload });
  if (!response?.ok) {
    throw new Error(response?.error || `Runtime message failed: ${type}`);
  }
  return response.result;
}

// src/debug/debug.js
var app = document.getElementById("debug-app");
var filters = {
  category: "",
  onlyErrors: false
};
render();
await refreshLogs();
setInterval(() => {
  refreshLogs().catch(() => {
  });
}, 1800);
function render() {
  app.innerHTML = `
    <div class="toolbar">
      <select id="category-filter" title="\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F">
        <option value="">all</option>
        ${Object.values(EVENT_CATEGORY).map((item) => `<option value="${escapeHtml(item)}">${escapeHtml(item)}</option>`).join("")}
      </select>
      <button id="errors-only" title="\u0422\u043E\u043B\u044C\u043A\u043E \u043E\u0448\u0438\u0431\u043A\u0438">!</button>
      <button id="download-log" title="\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u043B\u043E\u0433">\u2193</button>
      <button id="copy-log" title="\u041A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043B\u043E\u0433">\u2398</button>
    </div>
    <div id="log-list"></div>
  `;
  app.querySelector("#category-filter")?.addEventListener("change", async (event) => {
    filters.category = event.target.value;
    await refreshLogs();
  });
  app.querySelector("#errors-only")?.addEventListener("click", async () => {
    filters.onlyErrors = !filters.onlyErrors;
    await refreshLogs();
  });
  app.querySelector("#download-log")?.addEventListener("click", downloadLog);
  app.querySelector("#copy-log")?.addEventListener("click", copyLog);
}
async function refreshLogs() {
  const data = await callRuntime(MESSAGE.LOG_QUERY, {
    filters: {
      ...filters,
      limit: 1500
    }
  });
  app.querySelector("#category-filter").value = filters.category;
  app.querySelector("#errors-only").style.background = filters.onlyErrors ? "#111" : "#fff";
  app.querySelector("#errors-only").style.color = filters.onlyErrors ? "#fff" : "#111";
  app.querySelector("#log-list").innerHTML = data.items.map((row) => {
    const summary = `${row.ts} | ${row.level} | ${row.category} | ${row.name}`;
    const payload = JSON.stringify(
      {
        pageSessionId: row.pageSessionId,
        tabId: row.tabId,
        batchId: row.batchId,
        blockId: row.blockId,
        data: row.data,
        error: row.error
      },
      null,
      2
    );
    return `<details><summary>${escapeHtml(summary)}</summary><pre>${escapeHtml(payload)}</pre></details>`;
  }).join("");
}
async function downloadLog() {
  const text = await callRuntime(MESSAGE.LOG_EXPORT, { filters });
  const blob = new Blob([text], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  await chrome.downloads.download({
    url,
    filename: `neuro-translate-debug-log-${Date.now()}.json`,
    saveAs: true
  });
  setTimeout(() => URL.revokeObjectURL(url), 1e3);
}
async function copyLog() {
  const text = await callRuntime(MESSAGE.LOG_EXPORT, { filters });
  await navigator.clipboard.writeText(text);
}
function escapeHtml(text) {
  return String(text).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#39;");
}
//# sourceMappingURL=debug.js.map
